import React, { createContext, useState, useEffect, useContext } from 'react';
import { api } from '../services/api.js';

const AuthContext = createContext(null);

const normalizeAuthPayload = (payload) => {
  if (!payload) {
    return { token: null, user: null };
  }

  if (payload.user) {
    return {
      token: payload.token || null,
      user: {
        id: payload.user._id,
        ...payload.user,
      },
    };
  }

  return {
    token: payload.token || null,
    user: payload._id ? { id: payload._id, ...payload } : null,
  };
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkLoggedIn = async () => {
      try {
        const storedUser = localStorage.getItem('user');
        if (storedUser) {
          setUser(JSON.parse(storedUser));
        }
      } catch (error) {
        console.error('Failed to parse user from localStorage', error);
        localStorage.removeItem('user');
        localStorage.removeItem('token');
      } finally {
        setLoading(false);
      }
    };
    checkLoggedIn();
  }, []);

  const persistSession = ({ token, user: normalizedUser }) => {
    setUser(normalizedUser);
    if (token) {
      localStorage.setItem('token', token);
    }
    localStorage.setItem('user', JSON.stringify(normalizedUser));
    return normalizedUser;
  };

  const login = async (credentials) => {
    const authPayload = normalizeAuthPayload(await api.login(credentials));
    return persistSession(authPayload);
  };

  /** Creates an account without logging in — user must sign in afterward. */
  const register = async (userInfo) => {
    await api.signup(userInfo);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    window.location.hash = '';
    window.location.reload();
  };

  const value = {
    user,
    isAuthenticated: !!user,
    loading,
    login,
    register,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
