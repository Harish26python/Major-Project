const getStoredToken = () => localStorage.getItem('token');

const buildHeaders = (includeJson = true) => {
  const headers = {};
  if (includeJson) {
    headers['Content-Type'] = 'application/json';
  }

  const token = getStoredToken();
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  return headers;
};

const handleResponse = async (response) => {
  if (!response.ok) {
    let errorData;
    try {
      errorData = await response.json();
    } catch (e) {
      errorData = { message: 'An unknown error occurred' };
    }

    const errorMessage = errorData.message || errorData.error || `HTTP error! status: ${response.status}`;
    // Avoid console noise for expected 4xx (validation, duplicates, auth). Log server errors only.
    if (import.meta.env.DEV && response.status >= 500) {
      console.warn('API server error:', response.status, response.url, errorMessage);
    }

    throw new Error(errorMessage);
  }

  const contentType = response.headers.get('content-type');
  if (contentType && contentType.includes('application/json')) {
    return response.json();
  }

  return {};
};

const apiRequest = (url, method = 'GET', body) => fetch(url, {
  method,
  headers: buildHeaders(body !== undefined),
  body: body !== undefined ? JSON.stringify(body) : undefined,
}).then(handleResponse);

export const api = {
  login: (credentials) => apiRequest('/api/login', 'POST', credentials),
  signup: (userInfo) => apiRequest('/api/signup', 'POST', userInfo),
  getCurrentUser: () => apiRequest('/api/me'),

  getStudentDashboardData: (studentId) => apiRequest(studentId ? `/api/dashboard/student/${studentId}` : '/api/dashboard/student'),
  getDriverDashboardData: (driverId) => apiRequest(driverId ? `/api/dashboard/driver/${driverId}` : '/api/dashboard/driver'),
  getAdminDashboardData: () => apiRequest('/api/dashboard/admin'),

  updateBusStatus: (busId, status, currentLocation) => apiRequest(`/api/bus/${busId}/status`, 'POST', { status, currentLocation }),
  postAnnouncement: (message, routeId = null) => apiRequest('/api/announcements', 'POST', { message, routeId }),

  createUser: (userData) => apiRequest('/api/admin/users', 'POST', userData),
  updateUser: (userId, userData) => apiRequest(`/api/admin/users/${userId}`, 'PUT', userData),
  deleteUser: (userId) => apiRequest(`/api/admin/users/${userId}`, 'DELETE'),

  createRoute: (routeData) => apiRequest('/api/admin/routes', 'POST', routeData),
  updateRoute: (routeId, routeData) => apiRequest(`/api/admin/routes/${routeId}`, 'PUT', routeData),
  deleteRoute: (routeId) => apiRequest(`/api/admin/routes/${routeId}`, 'DELETE'),

  createBus: (busData) => apiRequest('/api/admin/buses', 'POST', busData),
  updateBus: (busId, busData) => apiRequest(`/api/admin/buses/${busId}`, 'PUT', busData),
  deleteBus: (busId) => apiRequest(`/api/admin/buses/${busId}`, 'DELETE'),
};
