import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { api } from '../../services/api.js';

const initialUserForm = {
  id: null,
  name: '',
  email: '',
  password: '',
  role: 'student',
  instituteId: '',
  routeId: '',
  busId: '',
};

const initialRouteForm = {
  id: null,
  routeName: '',
  distance: '',
  assignedVehicle: '',
  stopsText: '',
};

const initialBusForm = {
  id: null,
  vehicleNumber: '',
  type: 'bus',
  capacity: '',
  insuranceExpiry: '',
  status: 'active',
};

const PlusIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="12" y1="5" x2="12" y2="19"></line>
    <line x1="5" y1="12" x2="19" y2="12"></line>
  </svg>
);

const EditIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 20h9"></path>
    <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"></path>
  </svg>
);

const AdminDashboard = () => {
  const { user } = useAuth();
  const isTransportManager = user?.role === 'transport_manager';
  const [activeTab, setActiveTab] = useState('users');
  const [data, setData] = useState({ users: [], routes: [], buses: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState('');
  const [saving, setSaving] = useState(false);

  const [showUserPanel, setShowUserPanel] = useState(false);
  const [showRoutePanel, setShowRoutePanel] = useState(false);
  const [showBusPanel, setShowBusPanel] = useState(false);

  const [userForm, setUserForm] = useState(initialUserForm);
  const [routeForm, setRouteForm] = useState(initialRouteForm);
  const [busForm, setBusForm] = useState(initialBusForm);
  const [busValidationError, setBusValidationError] = useState('');

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const adminData = await api.getAdminDashboardData();
      setData({
        users: adminData.users || [],
        routes: adminData.routes || [],
        buses: adminData.buses || [],
      });
    } catch (err) {
      setError(err.message || 'Failed to load admin data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const getRouteName = (routeId) => data.routes.find((route) => route._id === routeId)?.routeName || 'Unassigned';
  const getBusName = (busId) => data.buses.find((bus) => bus._id === busId)?.vehicleNumber || 'Unassigned';

  const resetUserForm = () => {
    setUserForm(initialUserForm);
    setShowUserPanel(false);
  };

  const resetRouteForm = () => {
    setRouteForm(initialRouteForm);
    setShowRoutePanel(false);
  };

  const resetBusForm = () => {
    setBusForm(initialBusForm);
    setBusValidationError('');
    setShowBusPanel(false);
  };

  const normalizePlateKey = (value) => String(value ?? '').trim().normalize('NFKC').toLowerCase();

  const validateBusForm = (form) => {
    const vehicleKey = normalizePlateKey(form.vehicleNumber);
    if (!vehicleKey) {
      return 'Vehicle number is required.';
    }

    const duplicate = data.buses.some(
      (bus) =>
        normalizePlateKey(bus.vehicleNumber) === vehicleKey
        && (!form.id || bus._id !== form.id),
    );
    if (duplicate) {
      return 'A bus with this vehicle number is already listed. Use a different number or edit the existing bus.';
    }

    if (!form.capacity || Number.isNaN(Number(form.capacity))) {
      return 'Capacity must be a valid number.';
    }

    if (Number(form.capacity) < 1) {
      return 'Capacity must be at least 1.';
    }

    return '';
  };

  const parseStops = (stopsText) => stopsText
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const [stopName, arrivalTime] = line.split('|').map((part) => part.trim());
      return { stopName, arrivalTime };
    })
    .filter((stop) => stop.stopName && stop.arrivalTime);

  const formatStops = (stops = []) => stops
    .map((stop) => `${stop.stopName || ''} | ${stop.arrivalTime || ''}`)
    .join('\n');

  const handleDelete = async (type, id) => {
    if (!window.confirm(`Are you sure you want to delete this ${type.slice(0, -1)}?`)) return;

    try {
      if (type === 'users') await api.deleteUser(id);
      if (type === 'routes') await api.deleteRoute(id);
      if (type === 'buses') await api.deleteBus(id);
      setMessage(`${type.slice(0, -1)} deleted successfully.`);
      await fetchData();
    } catch (err) {
      setMessage(err.message || `Failed to delete ${type.slice(0, -1)}.`);
    }
  };

  const openEditUser = (user) => {
    setUserForm({
      id: user._id,
      name: user.name || '',
      email: user.email || '',
      password: '',
      role: user.role || 'student',
      instituteId: user.instituteId || '',
      routeId: user.routeId || '',
      busId: user.busId || '',
    });
    setShowUserPanel(true);
    setMessage('');
  };

  const openEditRoute = (route) => {
    setRouteForm({
      id: route._id,
      routeName: route.routeName || '',
      distance: route.distance ?? '',
      assignedVehicle: route.assignedVehicle?._id || route.assignedVehicle || '',
      stopsText: formatStops(route.stops),
    });
    setShowRoutePanel(true);
    setMessage('');
  };

  const openEditBus = (bus) => {
    setBusForm({
      id: bus._id,
      vehicleNumber: bus.vehicleNumber || '',
      type: bus.type || 'bus',
      capacity: bus.capacity ?? '',
      insuranceExpiry: bus.insuranceExpiry ? new Date(bus.insuranceExpiry).toISOString().slice(0, 10) : '',
      status: bus.status || 'active',
    });
    setShowBusPanel(true);
    setBusValidationError('');
    setMessage('');
  };

  const handleUserSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setMessage('');

    try {
      const payload = {
        name: userForm.name,
        email: userForm.email,
        role: userForm.role,
        instituteId: userForm.instituteId,
        routeId: userForm.routeId || null,
        busId: userForm.busId || null,
      };

      if (userForm.password) {
        payload.password = userForm.password;
      }

      if (userForm.id) {
        await api.updateUser(userForm.id, payload);
        setMessage('User updated successfully.');
      } else {
        await api.createUser({
          ...payload,
          password: userForm.password,
        });
        setMessage('User created successfully.');
      }

      await fetchData();
      resetUserForm();
    } catch (err) {
      setMessage(err.message || 'Failed to save user.');
    } finally {
      setSaving(false);
    }
  };

  const handleRouteSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setMessage('');

    try {
      const payload = {
        routeName: routeForm.routeName,
        distance: Number(routeForm.distance || 0),
        assignedVehicle: routeForm.assignedVehicle || null,
        stops: parseStops(routeForm.stopsText),
      };

      if (routeForm.id) {
        await api.updateRoute(routeForm.id, payload);
        setMessage('Route updated successfully.');
      } else {
        await api.createRoute(payload);
        setMessage('Route created successfully.');
      }

      await fetchData();
      resetRouteForm();
    } catch (err) {
      setMessage(err.message || 'Failed to save route.');
    } finally {
      setSaving(false);
    }
  };

  const handleBusSubmit = async (e) => {
    e.preventDefault();
    setBusValidationError('');
    
    const validationError = validateBusForm(busForm);
    if (validationError) {
      setBusValidationError(validationError);
      return;
    }

    setSaving(true);
    setMessage('');

    try {
      const payload = {
        vehicleNumber: busForm.vehicleNumber,
        type: busForm.type,
        capacity: Number(busForm.capacity),
        insuranceExpiry: busForm.insuranceExpiry || null,
        status: busForm.status,
      };

      if (busForm.id) {
        await api.updateBus(busForm.id, payload);
        setMessage('Bus updated successfully.');
      } else {
        await api.createBus(payload);
        setMessage('Bus created successfully.');
      }

      await fetchData();
      resetBusForm();
    } catch (err) {
      const msg = err.message || 'Failed to save bus.';
      setBusValidationError(msg);
      setMessage('');
      try {
        await fetchData();
      } catch {
        /* ignore refresh errors after failed save */
      }
    } finally {
      setSaving(false);
    }
  };

  const renderUsersTab = () => (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-xl font-semibold">Users</h2>
          <p className="text-sm text-brand-text-secondary">Create, update, delete, and assign route and bus access by role.</p>
        </div>
        <button
          onClick={() => {
            setShowUserPanel((prev) => !prev);
            setUserForm(initialUserForm);
            setMessage('');
          }}
          className="inline-flex items-center gap-2 px-4 py-2 font-semibold text-white rounded-lg bg-brand-primary hover:bg-brand-primary/90"
        >
          <PlusIcon /> {showUserPanel ? 'Close User Form' : 'Create User'}
        </button>
      </div>

      {showUserPanel && (
        <form onSubmit={handleUserSubmit} className="p-4 rounded-lg bg-black/20">
          <div className="grid gap-4 md:grid-cols-2">
            <input value={userForm.name} onChange={(e) => setUserForm((prev) => ({ ...prev, name: e.target.value }))} required className="w-full p-3 bg-transparent border rounded-lg border-white/20" placeholder="Full Name" />
            <input value={userForm.email} onChange={(e) => setUserForm((prev) => ({ ...prev, email: e.target.value }))} required type="email" className="w-full p-3 bg-transparent border rounded-lg border-white/20" placeholder="Email Address" />
            <input value={userForm.password} onChange={(e) => setUserForm((prev) => ({ ...prev, password: e.target.value }))} type="password" required={!userForm.id} className="w-full p-3 bg-transparent border rounded-lg border-white/20" placeholder={userForm.id ? 'New Password (optional)' : 'Password'} />
            <input value={userForm.instituteId} onChange={(e) => setUserForm((prev) => ({ ...prev, instituteId: e.target.value }))} required className="w-full p-3 bg-transparent border rounded-lg border-white/20" placeholder="Institute ID" />
            <select value={userForm.role} onChange={(e) => setUserForm((prev) => ({ ...prev, role: e.target.value, routeId: '', busId: '' }))} required className="w-full p-3 bg-transparent border rounded-lg border-white/20">
              <option value="student">Student</option>
              <option value="driver">Driver</option>
              {!isTransportManager && <option value="admin">Admin</option>}
              {!isTransportManager && <option value="transport_manager">Transport Manager</option>}
            </select>
            <select value={userForm.routeId} onChange={(e) => setUserForm((prev) => ({ ...prev, routeId: e.target.value }))} className="w-full p-3 bg-transparent border rounded-lg border-white/20">
              <option value="">Select Route</option>
              {data.routes.map((route) => (
                <option key={route._id} value={route._id}>{route.routeName}</option>
              ))}
            </select>
            <select value={userForm.busId} onChange={(e) => setUserForm((prev) => ({ ...prev, busId: e.target.value }))} className="w-full p-3 bg-transparent border rounded-lg border-white/20 md:col-span-2">
              <option value="">Select Bus</option>
              {data.buses.map((bus) => (
                <option key={bus._id} value={bus._id}>{bus.vehicleNumber}</option>
              ))}
            </select>
          </div>
          <div className="flex items-center justify-between gap-3 mt-4">
            <span className="text-sm text-brand-text-secondary">Admins can assign route and bus references directly from here.</span>
            <div className="flex gap-3">
              {userForm.id && (
                <button type="button" onClick={resetUserForm} className="px-4 py-2 text-sm font-semibold rounded-lg bg-white/10 hover:bg-white/15">
                  Cancel
                </button>
              )}
              <button type="submit" disabled={saving} className="px-5 py-2 font-semibold text-white rounded-lg bg-brand-accent hover:bg-brand-accent/90 disabled:opacity-50">
                {saving ? 'Saving...' : userForm.id ? 'Update User' : 'Create User'}
              </button>
            </div>
          </div>
        </form>
      )}

      <div className="space-y-3">
        {data.users.map((user) => (
          <div key={user._id} className="p-4 rounded-lg bg-brand-surface">
            <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
              <div>
                <p className="text-lg font-semibold">{user.name}</p>
                <p className="text-sm text-brand-text-secondary">{user.email} · <span className="uppercase">{user.role}</span></p>
                <p className="mt-2 text-sm text-brand-text-secondary">Institute ID: {user.instituteId}</p>
                <p className="mt-1 text-sm text-brand-text-secondary">Route: {getRouteName(user.routeId)}</p>
                <p className="mt-1 text-sm text-brand-text-secondary">Bus: {getBusName(user.busId)}</p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {(!isTransportManager || !['admin', 'transport_manager'].includes(user.role)) && (
                <button onClick={() => openEditUser(user)} className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white rounded-lg bg-brand-primary hover:bg-brand-primary/90">
                  <EditIcon /> Edit
                </button>
              )}
              {(!isTransportManager || !['admin', 'transport_manager'].includes(user.role)) && (
                <button onClick={() => handleDelete('users', user._id)} className="px-4 py-2 text-sm font-semibold text-white bg-red-500 rounded-lg hover:bg-red-400">
                  Delete
                </button>
              )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderRoutesTab = () => (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-xl font-semibold">Routes</h2>
          <p className="text-sm text-brand-text-secondary">Manage route names, stops, distance, and assigned buses.</p>
        </div>
        <button
          onClick={() => {
            setShowRoutePanel((prev) => !prev);
            setRouteForm(initialRouteForm);
            setMessage('');
          }}
          className="inline-flex items-center gap-2 px-4 py-2 font-semibold text-white rounded-lg bg-brand-primary hover:bg-brand-primary/90"
        >
          <PlusIcon /> {showRoutePanel ? 'Close Route Form' : 'Create Route'}
        </button>
      </div>

      {showRoutePanel && (
        <form onSubmit={handleRouteSubmit} className="p-4 rounded-lg bg-black/20">
          <div className="grid gap-4 md:grid-cols-2">
            <input value={routeForm.routeName} onChange={(e) => setRouteForm((prev) => ({ ...prev, routeName: e.target.value }))} required className="w-full p-3 bg-transparent border rounded-lg border-white/20" placeholder="Route Name" />
            <input value={routeForm.distance} onChange={(e) => setRouteForm((prev) => ({ ...prev, distance: e.target.value }))} type="number" min="0" step="0.1" className="w-full p-3 bg-transparent border rounded-lg border-white/20" placeholder="Distance (km)" />
            <select value={routeForm.assignedVehicle} onChange={(e) => setRouteForm((prev) => ({ ...prev, assignedVehicle: e.target.value }))} className="w-full p-3 bg-transparent border rounded-lg border-white/20 md:col-span-2">
              <option value="">Assigned Bus (optional)</option>
              {data.buses.map((bus) => (
                <option key={bus._id} value={bus._id}>{bus.vehicleNumber}</option>
              ))}
            </select>
            <textarea
              value={routeForm.stopsText}
              onChange={(e) => setRouteForm((prev) => ({ ...prev, stopsText: e.target.value }))}
              rows={5}
              className="w-full p-3 bg-transparent border rounded-lg border-white/20 md:col-span-2"
              placeholder={'Enter one stop per line in this format:\nMain Gate | 08:00 AM\nCentral Library | 08:15 AM'}
            />
          </div>
          <div className="flex items-center justify-between gap-3 mt-4">
            <span className="text-sm text-brand-text-secondary">Stops should be entered as `Stop Name | Arrival Time`.</span>
            <div className="flex gap-3">
              {routeForm.id && (
                <button type="button" onClick={resetRouteForm} className="px-4 py-2 text-sm font-semibold rounded-lg bg-white/10 hover:bg-white/15">
                  Cancel
                </button>
              )}
              <button type="submit" disabled={saving} className="px-5 py-2 font-semibold text-white rounded-lg bg-brand-accent hover:bg-brand-accent/90 disabled:opacity-50">
                {saving ? 'Saving...' : routeForm.id ? 'Update Route' : 'Create Route'}
              </button>
            </div>
          </div>
        </form>
      )}

      <div className="space-y-3">
        {data.routes.map((route) => (
          <div key={route._id} className="p-4 rounded-lg bg-brand-surface">
            <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
              <div>
                <p className="font-semibold">{route.routeName}</p>
                <p className="text-sm text-brand-text-secondary">Distance: {route.distance || 0} km</p>
                <p className="text-sm text-brand-text-secondary">Assigned Bus: {getBusName(route.assignedVehicle?._id || route.assignedVehicle)}</p>
                <p className="mt-2 text-sm text-brand-text-secondary">{route.stops?.length || 0} stops configured</p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => openEditRoute(route)} className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white rounded-lg bg-brand-primary hover:bg-brand-primary/90">
                  <EditIcon /> Edit
                </button>
                <button onClick={() => handleDelete('routes', route._id)} className="px-4 py-2 text-sm font-semibold text-white bg-red-500 rounded-lg hover:bg-red-400">
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderBusesTab = () => (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-xl font-semibold">Buses</h2>
          <p className="text-sm text-brand-text-secondary">Manage vehicle numbers, type, capacity, insurance, and status.</p>
        </div>
        <button
          onClick={() => {
            setShowBusPanel((prev) => !prev);
            setBusForm(initialBusForm);
            setBusValidationError('');
            setMessage('');
          }}
          className="inline-flex items-center gap-2 px-4 py-2 font-semibold text-white rounded-lg bg-brand-primary hover:bg-brand-primary/90"
        >
          <PlusIcon /> {showBusPanel ? 'Close Bus Form' : 'Create Bus'}
        </button>
      </div>

      {showBusPanel && (
        <form onSubmit={handleBusSubmit} className="p-4 rounded-lg bg-black/20">
          {busValidationError && (
            <div className="p-3 mb-4 rounded-lg bg-red-500/20 border border-red-500/50">
              <p className="text-sm font-semibold text-red-300">{busValidationError}</p>
            </div>
          )}
          <div className="grid gap-4 md:grid-cols-2">
            <input value={busForm.vehicleNumber} onChange={(e) => { setBusForm((prev) => ({ ...prev, vehicleNumber: e.target.value })); setBusValidationError(''); }} className="w-full p-3 bg-transparent border rounded-lg border-white/20" placeholder="Vehicle Number" />
            <select value={busForm.type} onChange={(e) => { setBusForm((prev) => ({ ...prev, type: e.target.value })); setBusValidationError(''); }} className="w-full p-3 bg-transparent border rounded-lg border-white/20">
              <option value="bus">Bus</option>
              <option value="van">Van</option>
            </select>
            <input value={busForm.capacity} onChange={(e) => { setBusForm((prev) => ({ ...prev, capacity: e.target.value })); setBusValidationError(''); }} type="number" min="1" className="w-full p-3 bg-transparent border rounded-lg border-white/20" placeholder="Capacity" />
            <input value={busForm.insuranceExpiry} onChange={(e) => { setBusForm((prev) => ({ ...prev, insuranceExpiry: e.target.value })); setBusValidationError(''); }} type="date" className="w-full p-3 bg-transparent border rounded-lg border-white/20" />
            <select value={busForm.status} onChange={(e) => { setBusForm((prev) => ({ ...prev, status: e.target.value })); setBusValidationError(''); }} className="w-full p-3 bg-transparent border rounded-lg border-white/20 md:col-span-2">
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="maintenance">Maintenance</option>
              <option value="Idle">Idle</option>
              <option value="Running">Running</option>
              <option value="Maintenance">Maintenance (Legacy)</option>
            </select>
          </div>
          <div className="flex items-center justify-end gap-3 mt-4">
            {busForm.id && (
              <button type="button" onClick={resetBusForm} className="px-4 py-2 text-sm font-semibold rounded-lg bg-white/10 hover:bg-white/15">
                Cancel
              </button>
            )}
            <button type="submit" disabled={saving} className="px-5 py-2 font-semibold text-white rounded-lg bg-brand-accent hover:bg-brand-accent/90 disabled:opacity-50">
              {saving ? 'Saving...' : busForm.id ? 'Update Bus' : 'Create Bus'}
            </button>
          </div>
        </form>
      )}

      <div className="space-y-3">
        {data.buses.map((bus) => (
          <div key={bus._id} className="p-4 rounded-lg bg-brand-surface">
            <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
              <div>
                <p className="font-semibold">{bus.vehicleNumber}</p>
                <p className="text-sm text-brand-text-secondary">Type: {bus.type}</p>
                <p className="text-sm text-brand-text-secondary">Capacity: {bus.capacity}</p>
                <p className="text-sm text-brand-text-secondary">Status: {bus.status}</p>
                <p className="text-sm text-brand-text-secondary">Insurance Expiry: {bus.insuranceExpiry ? new Date(bus.insuranceExpiry).toLocaleDateString() : 'Not set'}</p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => openEditBus(bus)} className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white rounded-lg bg-brand-primary hover:bg-brand-primary/90">
                  <EditIcon /> Edit
                </button>
                <button onClick={() => handleDelete('buses', bus._id)} className="px-4 py-2 text-sm font-semibold text-white bg-red-500 rounded-lg hover:bg-red-400">
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  if (loading) {
    return <div className="flex items-center justify-center h-full py-10"><div className="w-12 h-12 border-4 border-dashed rounded-full animate-spin border-brand-primary"></div></div>;
  }

  if (error) {
    return <div className="text-center p-10 text-red-400">Error: {error}</div>;
  }

  return (
    <div className="container mx-auto animate-fade-in">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold">
            {isTransportManager ? 'Transport control panel' : 'Admin control panel'}
          </h1>
          <p className="mt-2 text-brand-text-secondary">
            {isTransportManager
              ? 'Manage students, drivers, routes, and buses. Creating admin or transport manager accounts is disabled for this role.'
              : 'Full CRUD for users, routes, and buses, plus direct assignment controls.'}
          </p>
        </div>
        {message && (
          <span className="text-sm font-medium rounded-lg px-3 py-2 bg-brand-surface text-brand-text-primary border border-white/10">
            {message}
          </span>
        )}
      </div>

      <div className="flex p-1 mt-6 space-x-1 rounded-lg bg-brand-surface w-fit">
        {['users', 'routes', 'buses'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors duration-300 ${activeTab === tab ? 'bg-brand-primary text-white' : 'text-brand-text-secondary hover:bg-white/10'}`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      <div className="mt-6">
        {activeTab === 'users' ? renderUsersTab() : activeTab === 'routes' ? renderRoutesTab() : renderBusesTab()}
      </div>
    </div>
  );
};

export default AdminDashboard;
