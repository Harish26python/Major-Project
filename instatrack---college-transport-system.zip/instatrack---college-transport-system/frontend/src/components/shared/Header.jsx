import React from 'react';

const LogoutIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
    <polyline points="16 17 21 12 16 7"></polyline>
    <line x1="21" y1="12" x2="9" y2="12"></line>
  </svg>
);

const Header = ({ user, onLogout }) => {
  const getRoleBadgeColor = (role) => {
    switch (role) {
      case 'admin': return 'bg-red-500/20 text-red-300 border-red-500/30';
      case 'transport_manager': return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'driver': return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      case 'student': return 'bg-green-500/20 text-green-300 border-green-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  const label = user.role === 'transport_manager' ? 'Transport Manager' : user.role;

  return (
    <header className="sticky top-0 z-20 w-full border-b bg-brand-bg/80 backdrop-blur-lg border-white/10">
      <div className="container flex items-center justify-between h-16 px-4 mx-auto md:px-8">
        <div className="flex items-center space-x-4">
          <div className="text-xl font-bold tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-brand-primary to-brand-secondary">
            InstaTrack
          </div>
          <div className={`px-2 py-1 text-xs font-semibold uppercase border rounded-md ${getRoleBadgeColor(user.role)}`}>
            {label}
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <span className="hidden text-sm sm:block text-brand-text-secondary">
            Welcome, <span className="font-semibold text-brand-text-primary">{user.name}</span>
          </span>
          <button
            onClick={onLogout}
            className="flex items-center px-4 py-2 text-sm font-semibold transition-colors duration-200 rounded-lg bg-brand-surface hover:bg-white/10 text-brand-text-secondary hover:text-brand-text-primary"
          >
            <LogoutIcon />
            <span className="ml-2 hidden md:block">Logout</span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
