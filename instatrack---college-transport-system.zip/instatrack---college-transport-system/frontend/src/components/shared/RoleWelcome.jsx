import React from 'react';

const ROLE_CONTENT = {
  student: {
    heading: 'Your trip dashboard',
    body: 'Follow your assigned route, live bus location when available, and official announcements.',
  },
  driver: {
    heading: 'Driver workspace',
    body: 'Start or end trips, send route announcements, and see students assigned to your run.',
  },
  admin: {
    heading: 'Administrator console',
    body: 'Full access to users, routes, and fleet data. Create accounts and wire students and drivers to the network.',
  },
  transport_manager: {
    heading: 'Transport operations',
    body: 'Run day-to-day transport: users, routes, and buses. You cannot create other admins or transport managers.',
  },
};

const RoleWelcome = ({ role, name }) => {
  const copy = ROLE_CONTENT[role] || {
    heading: 'Dashboard',
    body: 'Welcome to InstaTrack.',
  };

  return (
    <section className="p-5 mb-6 border rounded-2xl bg-gradient-to-br from-brand-surface to-black/30 border-white/10 md:p-6">
      <p className="text-xs font-semibold tracking-widest uppercase text-brand-secondary">Signed in as {name}</p>
      <h2 className="mt-2 text-2xl font-bold text-brand-text-primary md:text-3xl">{copy.heading}</h2>
      <p className="max-w-3xl mt-2 text-sm leading-relaxed text-brand-text-secondary md:text-base">{copy.body}</p>
    </section>
  );
};

export default RoleWelcome;
