import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.jsx';

const DriverDashboard = () => {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [busStatus, setBusStatus] = useState('Idle');
  const [announcement, setAnnouncement] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const dashboardData = await api.getDriverDashboardData(user.id);
        setData(dashboardData);
        setBusStatus(dashboardData.vehicle?.status === 'on_trip' ? 'Running' : dashboardData.vehicle?.status || 'Idle');
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [user.id]);

  const handleStatusToggle = async () => {
    const newStatus = busStatus === 'Running' ? 'Idle' : 'Running';
    try {
      await api.updateBusStatus(data.vehicle._id, newStatus);
      setBusStatus(newStatus);
      setData((prev) => ({ ...prev, vehicle: { ...prev.vehicle, status: newStatus } }));
    } catch (_error) {
      alert('Failed to update bus status.');
    }
  };

  const handleSendAnnouncement = async (e) => {
    e.preventDefault();
    if (!announcement.trim()) return;
    setIsSubmitting(true);
    try {
      await api.postAnnouncement(announcement, data.route?._id || null);
      setAnnouncement('');
      alert('Announcement sent successfully!');
    } catch (_error) {
      alert('Failed to send announcement.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) return <div className="flex items-center justify-center h-full py-10"><div className="w-12 h-12 border-4 border-dashed rounded-full animate-spin border-brand-primary"></div></div>;
  if (error) return <div className="text-center p-10 text-red-400">Error: {error}</div>;
  if (!data) return <div className="text-center p-10">Could not load driver data.</div>;

  const routeName = data.route?.routeName || 'No route assigned';
  const vehicleNumber = data.vehicle?.vehicleNumber || 'No vehicle assigned';
  const students = (data.students || []).map((entry) => entry.student || entry);

  return (
    <div className="container grid grid-cols-1 gap-6 mx-auto animate-fade-in md:grid-cols-3">
      <div className="space-y-6 md:col-span-2">
        <div className="p-6 border rounded-2xl bg-brand-surface border-white/10">
          <h2 className="text-xl font-bold">Trip controls</h2>
          <p className="mt-1 text-sm text-brand-text-secondary">Vehicle {vehicleNumber} · {routeName}</p>
          <div className="flex flex-col items-start mt-4 space-y-4 sm:flex-row sm:space-y-0 sm:items-center sm:space-x-6">
            <div className="flex items-center space-x-2">
              <span className="text-brand-text-secondary">Status:</span>
              <span className={`px-3 py-1 text-sm font-semibold rounded-full ${busStatus === 'Running' ? 'bg-green-500/20 text-green-300' : 'bg-gray-500/20 text-gray-300'}`}>
                {busStatus}
              </span>
            </div>
            <button
              onClick={handleStatusToggle}
              className={`px-6 py-2 font-semibold text-white transition-colors rounded-lg ${busStatus === 'Running' ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}`}
            >
              {busStatus === 'Running' ? 'End Trip' : 'Start Trip'}
            </button>
          </div>
        </div>

        <div className="p-6 border rounded-2xl bg-brand-surface border-white/10">
          <h2 className="text-xl font-bold">Send Announcement</h2>
          <p className="text-sm text-brand-text-secondary">This will be sent to all students on your route.</p>
          <form onSubmit={handleSendAnnouncement} className="flex flex-col mt-4 space-y-3 sm:flex-row sm:space-y-0 sm:space-x-3">
            <input
              type="text"
              value={announcement}
              onChange={(e) => setAnnouncement(e.target.value)}
              placeholder="e.g., Running 10 minutes late"
              className="flex-grow px-4 py-2 bg-transparent border rounded-lg border-white/20 focus:border-brand-primary focus:ring-brand-primary"
            />
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 font-semibold text-white transition-colors rounded-lg bg-brand-primary hover:bg-brand-primary/90 disabled:bg-brand-primary/50"
            >
              {isSubmitting ? 'Sending...' : 'Send'}
            </button>
          </form>
        </div>
      </div>

      <div className="space-y-6">
        <div className="p-6 border rounded-2xl bg-brand-surface border-white/10">
          <h3 className="text-lg font-semibold">Route Info</h3>
          <p className="text-brand-secondary">{routeName}</p>
          <p className="text-sm">Bus Number: <span className="font-semibold text-brand-text-primary">{vehicleNumber}</span></p>
        </div>
        <div className="p-6 border rounded-2xl bg-brand-surface border-white/10">
          <h3 className="text-lg font-semibold">Students on Route ({students.length})</h3>
          <ul className="mt-3 space-y-2 overflow-y-auto max-h-64">
            {students.map((student) => (
              <li key={student._id} className="text-sm text-brand-text-secondary">{student.name} - {student.instituteId}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default DriverDashboard;
