import React from 'react';

const LandingPage = ({ onNavigate }) => {
  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen p-4 overflow-hidden text-center isolate bg-brand-bg">
      {/* Aurora Background */}
      <div className="absolute top-0 left-0 w-full h-full -z-10 bg-[radial-gradient(ellipse_200%_100%_at_50%_-20%,rgba(168,85,247,0.3),rgba(79,70,229,0.0))] animate-aurora" />

      <main className="z-10 flex flex-col items-center animate-fade-in">
        <div className="px-6 py-2 mb-6 text-sm font-semibold border rounded-full border-brand-secondary/30 bg-brand-surface/50 text-brand-text-secondary animate-slide-up" style={{ animationDelay: '0.1s' }}>
          Welcome to the Future of College Transit
        </div>
        <h1 className="text-4xl font-bold tracking-tighter text-transparent md:text-7xl lg:text-8xl bg-clip-text bg-gradient-to-r from-brand-text-primary to-brand-text-secondary animate-slide-up" style={{ animationDelay: '0.2s' }}>
          InstaTrack Transit
        </h1>
        <p className="max-w-2xl mt-6 text-lg tracking-tight text-brand-text-secondary animate-slide-up" style={{ animationDelay: '0.3s' }}>
          Never miss your bus again. Real-time tracking, instant alerts, and seamless route management, all designed for the modern student.
        </p>
        <div className="flex flex-col mt-10 space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4 animate-slide-up" style={{ animationDelay: '0.4s' }}>
          <button 
            onClick={() => onNavigate('login')}
            className="px-8 py-3 font-semibold text-white transition-all duration-300 rounded-full bg-brand-primary hover:bg-brand-primary/90 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-brand-primary focus:ring-offset-2 focus:ring-offset-brand-bg"
          >
            Sign In
          </button>
          <button 
            onClick={() => onNavigate('signup')}
            className="px-8 py-3 font-semibold transition-all duration-300 border rounded-full text-brand-text-primary border-brand-surface bg-brand-surface/50 hover:bg-brand-surface hover:scale-105 focus:outline-none focus:ring-2 focus:ring-brand-secondary focus:ring-offset-2 focus:ring-offset-brand-bg"
          >
            Sign Up
          </button>
        </div>
      </main>

      <footer className="absolute bottom-0 z-10 p-4 text-xs text-brand-text-secondary/50">
        <p>&copy; {new Date().getFullYear()} InstaTrack. Built for the students, by the students.</p>
      </footer>
    </div>
  );
};

export default LandingPage;
