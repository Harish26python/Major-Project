import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.jsx';

const LoginPage = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();

  useEffect(() => {
    if (sessionStorage.getItem('insttrack_registration_ok')) {
      sessionStorage.removeItem('insttrack_registration_ok');
      setInfo('Account created. Sign in with your email and password.');
    }
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setInfo('');
    setLoading(true);
    try {
      await login({ email, password });
      // The App component will handle navigation to the dashboard
    } catch (err) {
      setError(err.message || 'Failed to login. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen p-4 bg-brand-bg">
      <div className="relative w-full max-w-md p-8 overflow-hidden border rounded-2xl bg-brand-surface border-white/10 animate-fade-in">
        <div className="absolute top-0 left-0 w-full h-full -z-10 bg-[radial-gradient(ellipse_200%_100%_at_50%_-20%,rgba(168,85,247,0.1),rgba(79,70,229,0.0))]" />
        
        <div className="text-center">
          <h2 className="text-3xl font-bold text-brand-text-primary">Welcome Back!</h2>
          <p className="mt-2 text-sm text-brand-text-secondary">Sign in to track your ride.</p>
        </div>

        {info && (
          <div className="p-3 mt-6 text-sm text-center text-emerald-300 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
            {info}
          </div>
        )}

        {error && (
          <div className="p-3 mt-6 text-sm text-center text-red-400 bg-red-500/10 rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-8 space-y-6">
          <div>
            <label htmlFor="email" className="sr-only">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 transition-all duration-300 bg-transparent border rounded-lg border-white/20 text-brand-text-primary focus:border-brand-primary focus:ring-brand-primary focus:outline-none"
              placeholder="Email Address"
            />
          </div>
          <div>
            <label htmlFor="password" className="sr-only">Password</label>
            <input
              id="password"
              name="password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 transition-all duration-300 bg-transparent border rounded-lg border-white/20 text-brand-text-primary focus:border-brand-primary focus:ring-brand-primary focus:outline-none"
              placeholder="Password"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full px-4 py-3 font-semibold text-white transition-all duration-300 rounded-lg bg-brand-primary hover:bg-brand-primary/90 disabled:bg-brand-primary/50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {loading ? (
              <div className="w-6 h-6 border-2 border-dashed rounded-full animate-spin border-white"></div>
            ) : (
              'Sign In'
            )}
          </button>
        </form>

        <p className="mt-8 text-sm text-center text-brand-text-secondary">
          Don't have an account?{' '}
          <button onClick={() => onNavigate('signup')} className="font-medium text-brand-secondary hover:underline">
            Sign up
          </button>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
