import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';

const SignUpPage = ({ onNavigate }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [instituteId, setInstituteId] = useState('');
  const [role, setRole] = useState('student');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await register({ name, email, password, role, instituteId });
      sessionStorage.setItem('insttrack_registration_ok', '1');
      onNavigate('login');
    } catch (err) {
      setError(err.message || 'Failed to sign up. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen p-4 bg-brand-bg">
      <div className="relative w-full max-w-md p-8 overflow-hidden border rounded-2xl bg-brand-surface border-white/10 animate-fade-in">
        <div className="absolute top-0 left-0 w-full h-full -z-10 bg-[radial-gradient(ellipse_200%_100%_at_50%_-20%,rgba(236,72,153,0.1),rgba(79,70,229,0.0))]" />
        
        <div className="text-center">
          <h2 className="text-3xl font-bold text-brand-text-primary">Create Account</h2>
          <p className="mt-2 text-sm text-brand-text-secondary">Get on board with InstaTrack.</p>
        </div>

        {error && (
          <div className="p-3 mt-6 text-sm text-center text-red-400 bg-red-500/10 rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-8 space-y-4">
          <input
            type="text" required value={name} onChange={(e) => setName(e.target.value)}
            className="w-full px-4 py-3 transition-all duration-300 bg-transparent border rounded-lg border-white/20 text-brand-text-primary focus:border-brand-accent focus:ring-brand-accent"
            placeholder="Full Name"
          />
          <input
            type="text" required value={instituteId} onChange={(e) => setInstituteId(e.target.value)}
            className="w-full px-4 py-3 transition-all duration-300 bg-transparent border rounded-lg border-white/20 text-brand-text-primary focus:border-brand-accent focus:ring-brand-accent"
            placeholder="Institute ID (e.g., STU101)"
          />
          <input
            type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-3 transition-all duration-300 bg-transparent border rounded-lg border-white/20 text-brand-text-primary focus:border-brand-accent focus:ring-brand-accent"
            placeholder="Email Address"
          />
          <input
            type="password" required value={password} onChange={(e) => setPassword(e.target.value)}
            className="w-full px-4 py-3 transition-all duration-300 bg-transparent border rounded-lg border-white/20 text-brand-text-primary focus:border-brand-accent focus:ring-brand-accent"
            placeholder="Password"
          />
          <div className="flex justify-around p-1 rounded-lg bg-black/20">
            {['student', 'driver'].map((r) => (
              <button
                key={r} type="button" onClick={() => setRole(r)}
                className={`w-1/2 py-2 text-sm font-medium rounded-md transition-colors duration-300 ${role === r ? 'bg-brand-accent text-white' : 'text-brand-text-secondary hover:bg-white/10'}`}
              >
                {r.charAt(0).toUpperCase() + r.slice(1)}
              </button>
            ))}
          </div>
          <button
            type="submit" disabled={loading}
            className="w-full px-4 py-3 font-semibold text-white transition-all duration-300 rounded-lg bg-brand-accent hover:bg-brand-accent/90 disabled:bg-brand-accent/50 disabled:cursor-not-allowed flex items-center justify-center"
          >
             {loading ? (
              <div className="w-6 h-6 border-2 border-dashed rounded-full animate-spin border-white"></div>
            ) : (
              'Create Account'
            )}
          </button>
        </form>
        <p className="mt-8 text-sm text-center text-brand-text-secondary">
          Already have an account?{' '}
          <button onClick={() => onNavigate('login')} className="font-medium text-brand-secondary hover:underline">
            Sign in
          </button>
        </p>
      </div>
    </div>
  );
};

export default SignUpPage;
