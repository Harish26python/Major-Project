import React, { useState, useEffect } from 'react';

const MapView = ({ bus }) => {
  const [busPosition, setBusPosition] = useState({ x: 5, y: 80 }); // Start position in %

  useEffect(() => {
    let animationFrameId;
    
    if (bus.status === 'Running') {
      const path = [
        { x: 5, y: 80 }, { x: 20, y: 75 }, { x: 40, y: 60 },
        { x: 60, y: 40 }, { x: 75, y: 25 }, { x: 90, y: 10 }
      ];
      let step = 0;
      let progress = 0; // 0 to 1
      const duration = 5000; // 5 seconds per segment

      const animate = (timestamp) => {
        if (!startTime) startTime = timestamp;
        const elapsed = timestamp - startTime;
        progress = Math.min(elapsed / duration, 1);
        
        const startPoint = path[step];
        const endPoint = path[step + 1];

        const newX = startPoint.x + (endPoint.x - startPoint.x) * progress;
        const newY = startPoint.y + (endPoint.y - startPoint.y) * progress;
        setBusPosition({ x: newX, y: newY });

        if (progress < 1) {
          animationFrameId = requestAnimationFrame(animate);
        } else {
          step = (step + 1) % (path.length - 1);
          startTime = null;
          animationFrameId = requestAnimationFrame(animate);
        }
      };
      
      let startTime = null;
      animationFrameId = requestAnimationFrame(animate);

    } else {
      // If bus is not running, reset to start. You might want to persist last known location.
      setBusPosition({ x: 5, y: 80 });
    }

    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, [bus.status]);

  return (
    <div className="relative w-full overflow-hidden rounded-lg aspect-video bg-gray-800">
      <img
        src="https://picsum.photos/seed/collegemap/1280/720"
        alt="Map of college route"
        className="object-cover w-full h-full opacity-40"
      />
      {/* Route path (visual representation) */}
      <svg className="absolute top-0 left-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
        <path d="M 5 80 Q 30 70, 60 40 T 90 10" strokeDasharray="4 2" stroke="rgba(255,255,255,0.3)" strokeWidth="1" fill="none" />
      </svg>
      
      {/* Bus Icon */}
      <div 
        className="absolute transition-all duration-1000 ease-linear transform -translate-x-1/2 -translate-y-1/2"
        style={{ left: `${busPosition.x}%`, top: `${busPosition.y}%` }}
      >
        <div className="relative">
          <div className="w-8 h-8 rounded-full bg-brand-primary animate-ping"></div>
          <div className="absolute top-0 left-0 flex items-center justify-center w-8 h-8 rounded-full bg-brand-primary">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="white" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 17h2l.64-2.56a2 2 0 00-1.95-2.44H5.31a2 2 0 00-1.95 2.44L4 17h2"/><path d="M3 17h18"/><path d="M5 17L3 12h18l-2 5"/><path d="M8 12V8h8v4"/><path d="M10 4h4"/><circle cx="7" cy="20" r="2"/><circle cx="17" cy="20" r="2"/></svg>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MapView;
