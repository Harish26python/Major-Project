import React, { useState, useEffect } from 'react';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.jsx';
import MapView from './MapView.jsx';

const ClockIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>;
const RouteIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 2v4M12 20v2M5 12H3M21 12h-2M15.9 15.9l1.4 1.4M6.7 6.7l1.4 1.4"/></svg>;
const BusIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 17h2l.64-2.56a2 2 0 0 0-1.95-2.44H5.31a2 2 0 0 0-1.95 2.44L4 17h2"/><path d="M3 17h18"/><path d="M5 17L3 12h18l-2 5"/><path d="M8 12V8h8v4"/><path d="M10 4h4"/><circle cx="7" cy="20" r="2"/><circle cx="17" cy="20" r="2"/></svg>;

const StudentDashboard = () => {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const dashboardData = await api.getStudentDashboardData(user.id);
        setData(dashboardData);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user.id]);

  if (loading) return <div className="flex items-center justify-center h-full py-10"><div className="w-12 h-12 border-4 border-dashed rounded-full animate-spin border-brand-primary"></div></div>;
  if (error) return <div className="text-center p-10 text-red-400">Error: {error}</div>;

  const route = data?.route;
  const vehicle = data?.vehicle;
  const driver = data?.driver;
  const announcements = data?.announcements || [];
  const vehicleStatus = vehicle?.status === 'on_trip' ? 'Running' : vehicle?.status || 'Idle';

  if (!route) {
    return (
      <div className="max-w-xl mx-auto p-8 text-center border rounded-2xl bg-brand-surface border-white/10">
        <h2 className="text-xl font-semibold text-brand-text-primary">No route assigned yet</h2>
        <p className="mt-3 text-sm text-brand-text-secondary">
          Once transport assigns you to a route, your map, stops, and driver details will show here. If you just signed up, ask your college transport office to link your account.
        </p>
      </div>
    );
  }

  return (
    <div className="container mx-auto animate-fade-in">
      {user?.instituteId && (
        <p className="mb-4 text-sm text-brand-text-secondary">
          Institute ID: <span className="font-mono font-semibold text-brand-text-primary">{user.instituteId}</span>
        </p>
      )}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="p-6 border rounded-2xl bg-brand-surface border-white/10">
            <h2 className="text-xl font-bold">Real-time Bus Location</h2>
            <p className="mb-4 text-sm text-brand-text-secondary">Your bus: {vehicle?.vehicleNumber || 'Unassigned'} - {route.routeName}</p>
            <MapView bus={{ status: vehicleStatus, location: vehicle?.currentLocation }} />
          </div>
        </div>

        <div className="space-y-6">
          <div className="p-6 border rounded-2xl bg-brand-surface border-white/10">
            <div className="flex items-center mb-4 space-x-3">
              <RouteIcon />
              <h3 className="text-lg font-semibold">Your Route Details</h3>
            </div>
            <h4 className="font-bold text-brand-secondary">{route.routeName}</h4>
            <ul className="mt-3 space-y-2">
              {(route.stops || []).map((stop, index) => (
                <li key={index} className="flex items-center text-sm text-brand-text-secondary">
                  <ClockIcon />
                  <span className="ml-2 font-medium text-brand-text-primary">{stop.arrivalTime}</span>
                  <span className="ml-2">- {stop.stopName}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="p-6 border rounded-2xl bg-brand-surface border-white/10">
            <div className="flex items-center mb-4 space-x-3">
              <BusIcon />
              <h3 className="text-lg font-semibold">Bus & Driver Info</h3>
            </div>
            <p className="text-sm">Bus Number: <span className="font-semibold text-brand-text-primary">{vehicle?.vehicleNumber || 'Unassigned'}</span></p>
            <p className="text-sm">Driver: <span className="font-semibold text-brand-text-primary">{driver?.name || 'Not assigned'}</span></p>
            <p className="mt-2 text-sm">Status:
              <span className={`ml-2 px-2 py-1 text-xs font-semibold rounded-full ${vehicleStatus === 'Running' ? 'bg-green-500/20 text-green-300' : 'bg-gray-500/20 text-gray-300'}`}>
                {vehicleStatus}
              </span>
            </p>
          </div>

          <div className="p-6 border rounded-2xl bg-brand-surface border-white/10">
            <h3 className="mb-4 text-lg font-semibold">Announcements</h3>
            <div className="space-y-3 overflow-y-auto max-h-48">
              {announcements.map((ann) => (
                <div key={ann._id} className="p-3 text-sm border-l-2 border-brand-accent bg-brand-accent/10">
                  <p>{ann.message}</p>
                  <p className="mt-1 text-xs text-brand-text-secondary">{new Date(ann.createdAt).toLocaleString()}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
