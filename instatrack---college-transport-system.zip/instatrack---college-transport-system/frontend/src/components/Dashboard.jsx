import React from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import StudentDashboard from './student/StudentDashboard.jsx';
import DriverDashboard from './driver/DriverDashboard.jsx';
import AdminDashboard from './admin/AdminDashboard.jsx';
import Header from './shared/Header.jsx';
import RoleWelcome from './shared/RoleWelcome.jsx';

const Dashboard = () => {
  const { user, logout } = useAuth();

  const renderDashboardByRole = () => {
    switch (user?.role) {
      case 'student':
        return <StudentDashboard />;
      case 'driver':
        return <DriverDashboard />;
      case 'admin':
      case 'transport_manager':
        return <AdminDashboard />;
      default:
        return (
          <div className="flex flex-col items-center justify-center h-full p-8 text-center">
            <h2 className="text-2xl font-bold text-red-400">Error: Unknown User Role</h2>
            <p className="mt-2 text-brand-text-secondary">Your account does not have a valid role assigned.</p>
            <button onClick={logout} className="px-6 py-2 mt-6 font-semibold text-white rounded-lg bg-brand-primary hover:bg-brand-primary/90">
              Logout
            </button>
          </div>
        );
    }
  };

  if (!user) {
    return <p>Loading user data...</p>;
  }

  return (
    <div className="flex flex-col min-h-screen bg-brand-bg">
      <Header user={user} onLogout={logout} />
      <main className="flex-grow p-4 md:p-8">
        {user?.role && <RoleWelcome role={user.role} name={user.name} />}
        {renderDashboardByRole()}
      </main>
    </div>
  );
};

export default Dashboard;
