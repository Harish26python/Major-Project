import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.jsx';
import LandingPage from './components/LandingPage.jsx';
import LoginPage from './components/LoginPage.jsx';
import SignUpPage from './components/SignUpPage.jsx';
import Dashboard from './components/Dashboard.jsx';

const AppContent = () => {
  const { user, loading } = useAuth();
  const [currentPage, setCurrentPage] = useState('landing');

  const normalizeHash = () => {
    const raw = window.location.hash.replace(/^#/, '');
    return raw.replace(/^\//, '');
  };

  useEffect(() => {
    if (!loading) {
      if (user) {
        setCurrentPage('dashboard');
        const h = normalizeHash();
        if (!h || h === 'login' || h === 'signup' || h === 'landing') {
          window.location.hash = 'dashboard';
        }
      } else {
        const hash = normalizeHash();
        if (hash === 'login' || hash === 'signup') {
          setCurrentPage(hash);
        } else {
          setCurrentPage('landing');
        }
      }
    }
  }, [user, loading]);

  const navigate = (page) => {
    setCurrentPage(page);
    window.location.hash = page;
  };
  
  const renderPage = () => {
    if (loading) {
      return (
        <div className="flex items-center justify-center min-h-screen bg-brand-bg">
          <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-brand-primary"></div>
        </div>
      );
    }

    if (user) {
      return <Dashboard />;
    }

    switch (currentPage) {
      case 'login':
        return <LoginPage onNavigate={navigate} />;
      case 'signup':
        return <SignUpPage onNavigate={navigate} />;
      case 'dashboard':
         // This case is handled by the `if (user)` block, but as a fallback:
        return <LandingPage onNavigate={navigate} />;
      case 'landing':
      default:
        return <LandingPage onNavigate={navigate} />;
    }
  };

  return <div className="min-h-screen bg-brand-bg">{renderPage()}</div>;
};

const App = () => {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
};

export default App;
