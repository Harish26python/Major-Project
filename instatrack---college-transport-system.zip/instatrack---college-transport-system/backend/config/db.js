
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Bus from '../models/busModel.js';

dotenv.config();

const MONGO_URI = process.env.MONGO_URI?.trim() || 'mongodb://localhost:27017/instatrack';

if (!process.env.MONGO_URI) {
  console.warn('Warning: MONGO_URI not found in environment. Falling back to local MongoDB.');
}

/** True if URI path already selects a database (otherwise MongoDB defaults to "test"). */
const mongoUriSelectsDatabase = (uri) => {
  const noQuery = uri.split('?')[0].replace(/\/+$/, '');
  const rest = noQuery.replace(/^mongodb(\+srv)?:\/\//i, '');
  const i = rest.indexOf('/');
  return i !== -1 && rest.slice(i + 1).length > 0;
};

const connectDB = async () => {
  try {
    const connectOptions = {};
    if (process.env.MONGO_DB_NAME?.trim()) {
      connectOptions.dbName = process.env.MONGO_DB_NAME.trim();
    }

    const conn = await mongoose.connect(MONGO_URI, connectOptions);
    const dbName = conn.connection.name;
    console.log(`MongoDB Connected: ${conn.connection.host} (database: "${dbName}")`);

    if (dbName === 'test' && !process.env.MONGO_DB_NAME?.trim() && !mongoUriSelectsDatabase(MONGO_URI)) {
      console.warn(
        '\n[MongoDB] You are on the default database "test". Put your database in the URI (e.g. ...mongodb.net/instatrack) '
        + 'or set MONGO_DB_NAME in .env so Compass and this app use the same database.\n',
      );
    }

    try {
      await Bus.syncIndexes();
    } catch (syncErr) {
      console.warn('Bus.syncIndexes:', syncErr.message);
    }
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

export default connectDB;