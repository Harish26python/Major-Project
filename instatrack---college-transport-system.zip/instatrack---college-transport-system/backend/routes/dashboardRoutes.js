import express from 'express';
import { getStudentDashboard, getDriverDashboard, getAdminDashboard } from '../controllers/dashboardController.js';
import authMiddleware from '../middleware/authMiddleware.js';
import roleMiddleware from '../middleware/roleMiddleware.js';

const router = express.Router();

router.get('/student', authMiddleware, roleMiddleware('student', 'admin', 'transport_manager'), getStudentDashboard);
router.get('/student/:id', authMiddleware, roleMiddleware('student', 'admin', 'transport_manager'), getStudentDashboard);

router.get('/driver', authMiddleware, roleMiddleware('driver', 'admin', 'transport_manager'), getDriverDashboard);
router.get('/driver/:id', authMiddleware, roleMiddleware('driver', 'admin', 'transport_manager'), getDriverDashboard);

router.get('/admin', authMiddleware, roleMiddleware('admin', 'transport_manager'), getAdminDashboard);

export default router;
