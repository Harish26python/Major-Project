import express from 'express';
import authMiddleware from '../middleware/authMiddleware.js';
import roleMiddleware from '../middleware/roleMiddleware.js';
import {
  listVehicles,
  getVehicleById,
  createVehicle,
  updateVehicle,
  deleteVehicle,
  listDrivers,
  createDriverProfile,
  updateDriverProfile,
  deleteDriverProfile,
  listRoutes,
  getRouteById,
  createRoute,
  updateRoute,
  deleteRoute,
  assignDriverToVehicle,
  assignVehicleToRoute,
  listStudentAssignments,
  createStudentAssignment,
  updateStudentAssignment,
  deleteStudentAssignment,
  listTrips,
  createTrip,
  updateTrip,
  getReports,
} from '../controllers/transportController.js';

const router = express.Router();

router.use(authMiddleware);

router.get('/vehicles', listVehicles);
router.get('/vehicles/:id', getVehicleById);
router.post('/vehicles', roleMiddleware('admin', 'transport_manager'), createVehicle);
router.put('/vehicles/:id', roleMiddleware('admin', 'transport_manager'), updateVehicle);
router.delete('/vehicles/:id', roleMiddleware('admin', 'transport_manager'), deleteVehicle);

router.get('/drivers', roleMiddleware('admin', 'transport_manager'), listDrivers);
router.post('/drivers', roleMiddleware('admin', 'transport_manager'), createDriverProfile);
router.put('/drivers/:id', roleMiddleware('admin', 'transport_manager'), updateDriverProfile);
router.delete('/drivers/:id', roleMiddleware('admin', 'transport_manager'), deleteDriverProfile);

router.get('/routes', listRoutes);
router.get('/routes/:id', getRouteById);
router.post('/routes', roleMiddleware('admin', 'transport_manager'), createRoute);
router.put('/routes/:id', roleMiddleware('admin', 'transport_manager'), updateRoute);
router.delete('/routes/:id', roleMiddleware('admin', 'transport_manager'), deleteRoute);

router.post('/assign/driver-vehicle', roleMiddleware('admin', 'transport_manager'), assignDriverToVehicle);
router.post('/assign/vehicle-route', roleMiddleware('admin', 'transport_manager'), assignVehicleToRoute);

router.get('/student-assignments', roleMiddleware('admin', 'transport_manager'), listStudentAssignments);
router.post('/student-assignments', roleMiddleware('admin', 'transport_manager'), createStudentAssignment);
router.put('/student-assignments/:id', roleMiddleware('admin', 'transport_manager'), updateStudentAssignment);
router.delete('/student-assignments/:id', roleMiddleware('admin', 'transport_manager'), deleteStudentAssignment);

router.get('/trips', listTrips);
router.post('/trips', roleMiddleware('admin', 'transport_manager', 'driver'), createTrip);
router.put('/trips/:id', roleMiddleware('admin', 'transport_manager', 'driver'), updateTrip);

router.get('/reports', roleMiddleware('admin', 'transport_manager'), getReports);

export default router;
