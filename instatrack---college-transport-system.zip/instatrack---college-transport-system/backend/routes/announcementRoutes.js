
import express from 'express';
import { postAnnouncement } from '../controllers/announcementController.js';

const router = express.Router();

router.post('/', postAnnouncement);

export default router;
