import express from 'express';
import { updateBusStatus } from '../controllers/busController.js';
import authMiddleware from '../middleware/authMiddleware.js';
import roleMiddleware from '../middleware/roleMiddleware.js';

const router = express.Router();

router.post('/:id/status', authMiddleware, roleMiddleware('admin', 'transport_manager', 'driver'), updateBusStatus);

export default router;
