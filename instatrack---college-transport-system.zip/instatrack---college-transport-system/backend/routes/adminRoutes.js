import express from 'express';
import {
  createUser, updateUser, deleteUser,
  createRoute, updateRoute, deleteRoute,
  createBus, updateBus, deleteBus,
} from '../controllers/adminController.js';
import authMiddleware from '../middleware/authMiddleware.js';
import roleMiddleware from '../middleware/roleMiddleware.js';

const router = express.Router();

router.use(authMiddleware);

router.post('/users', roleMiddleware('admin', 'transport_manager'), createUser);
router.put('/users/:id', roleMiddleware('admin', 'transport_manager'), updateUser);
router.delete('/users/:id', roleMiddleware('admin', 'transport_manager'), deleteUser);

router.post('/routes', roleMiddleware('admin', 'transport_manager'), createRoute);
router.put('/routes/:id', roleMiddleware('admin', 'transport_manager'), updateRoute);
router.delete('/routes/:id', roleMiddleware('admin', 'transport_manager'), deleteRoute);

router.post('/buses', roleMiddleware('admin', 'transport_manager'), createBus);
router.put('/buses/:id', roleMiddleware('admin', 'transport_manager'), updateBus);
router.delete('/buses/:id', roleMiddleware('admin', 'transport_manager'), deleteBus);

export default router;
