import dotenv from 'dotenv';
import connectDB from './config/db.js';
import Bus from './models/busModel.js';

dotenv.config();

const run = async () => {
  await connectDB();
  try {
    const payload = {
      vehicleNumber: 'C-999',
      type: 'van',
      capacity: 20,
      insuranceExpiry: new Date('2026-12-04'),
      status: 'active',
    };
    const bus = new Bus(payload);
    await bus.save();
    console.log('saved', bus);
  } catch (error) {
    console.error('error', error);
    if (error.code === 11000) {
      console.error('duplicate key info', error.keyValue);
    }
  } finally {
    process.exit(0);
  }
};

run();