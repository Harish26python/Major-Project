import User from '../models/userModel.js';
import Route from '../models/routeModel.js';
import Bus from '../models/busModel.js';
import Announcement from '../models/announcementModel.js';
import Driver from '../models/driverModel.js';
import StudentTransport from '../models/studentTransportModel.js';
import Trip from '../models/tripModel.js';
import { buildTransportReports } from '../services/transportReportService.js';

const resolveRequestedUserId = (req) => req.params.id || req.user?._id?.toString();

const canAccessSelfOrManagerScope = (req, targetUserId, allowedRoles = []) => {
  if (!req.user) {
    return false;
  }

  if (req.user._id.toString() === targetUserId) {
    return true;
  }

  return allowedRoles.includes(req.user.role);
};

export const getStudentDashboard = async (req, res) => {
  try {
    const studentId = resolveRequestedUserId(req);

    if (!canAccessSelfOrManagerScope(req, studentId, ['admin', 'transport_manager'])) {
      return res.status(403).json({ message: 'Not authorized to view this student dashboard.' });
    }

    const student = await User.findById(studentId);
    if (!student || student.role !== 'student') {
      return res.status(404).json({ message: 'Student not found' });
    }

    const transport = await StudentTransport.findOne({ student: student._id })
      .populate({
        path: 'route',
        populate: [
          { path: 'assignedVehicle' },
          { path: 'assignedDriver' },
        ],
      });

    const route = transport?.route || await Route.findById(student.routeId)
      .populate('assignedVehicle')
      .populate('assignedDriver');

    const vehicle = route?.assignedVehicle || await Bus.findById(student.busId);
    const driver = route?.assignedDriver || (vehicle?.driver ? await User.findById(vehicle.driver) : null);

    const latestTrip = route?._id
      ? await Trip.findOne({ route: route._id }).sort({ createdAt: -1 }).populate('vehicle route driver')
      : null;

    const relevantAnnouncements = await Announcement.find({
      $or: [{ routeId: null }, { routeId: route?._id || student.routeId || null }],
    }).sort({ createdAt: -1 });

    const notifications = [];
    if (latestTrip?.status === 'delayed') {
      notifications.push({
        type: 'delay-alert',
        message: `${route?.routeName || 'Your bus'} is delayed.`,
        timestamp: latestTrip.updatedAt,
      });
    }
    if (latestTrip?.status === 'in-progress') {
      notifications.push({
        type: 'bus-arriving',
        message: `${vehicle?.vehicleNumber || 'Your bus'} is on the way to ${transport?.pickupPoint || 'your pickup point'}.`,
        timestamp: latestTrip.updatedAt,
      });
    }

    return res.json({
      student,
      transport,
      route,
      vehicle,
      driver,
      latestTrip,
      notifications,
      announcements: relevantAnnouncements,
    });
  } catch (error) {
    return res.status(500).json({ message: 'Server error', error: error.message });
  }
};

export const getDriverDashboard = async (req, res) => {
  try {
    const driverUserId = resolveRequestedUserId(req);

    if (!canAccessSelfOrManagerScope(req, driverUserId, ['admin', 'transport_manager'])) {
      return res.status(403).json({ message: 'Not authorized to view this driver dashboard.' });
    }

    const driverUser = await User.findById(driverUserId);
    if (!driverUser || driverUser.role !== 'driver') {
      return res.status(404).json({ message: 'Driver not found' });
    }

    const driverProfile = await Driver.findOne({ user: driverUser._id }).populate('assignedVehicle');
    const vehicle = driverProfile?.assignedVehicle || await Bus.findOne({ driver: driverUser._id });
    const route = await Route.findOne({
      $or: [{ assignedDriver: driverUser._id }, { assignedVehicle: vehicle?._id || null }],
    }).populate('assignedVehicle assignedDriver');

    const students = route?._id
      ? await StudentTransport.find({ route: route._id, status: 'active' }).populate('student')
      : [];

    const recentTrips = route?._id
      ? await Trip.find({ route: route._id }).sort({ createdAt: -1 }).limit(10)
      : [];

    return res.json({
      driver: driverUser,
      driverProfile,
      vehicle,
      route,
      students,
      recentTrips,
    });
  } catch (error) {
    return res.status(500).json({ message: 'Server error', error: error.message });
  }
};

export const getAdminDashboard = async (req, res) => {
  try {
    const [users, routes, buses, announcements, drivers, studentAssignments, reports] = await Promise.all([
      User.find({}).select('-password'),
      Route.find({}).populate('assignedVehicle assignedDriver'),
      Bus.find({}).populate('driver assignedRoute'),
      Announcement.find({}).sort({ createdAt: -1 }),
      Driver.find({}).populate('user assignedVehicle'),
      StudentTransport.find({}).populate('student route'),
      buildTransportReports(),
    ]);

    const now = new Date();
    const nextThirtyDays = new Date(now);
    nextThirtyDays.setDate(nextThirtyDays.getDate() + 30);

    const expiringVehicles = buses.filter((bus) => bus.insuranceExpiry && bus.insuranceExpiry <= nextThirtyDays);
    const expiringLicenses = drivers.filter((driver) => driver.licenseExpiry && driver.licenseExpiry <= nextThirtyDays);

    return res.json({
      users,
      routes,
      buses,
      announcements,
      drivers,
      studentAssignments,
      alerts: {
        expiringVehicles,
        expiringLicenses,
      },
      reports,
    });
  } catch (error) {
    return res.status(500).json({ message: 'Server error', error: error.message });
  }
};
