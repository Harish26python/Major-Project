import Bus from '../models/busModel.js';
import Trip from '../models/tripModel.js';

export const updateBusStatus = async (req, res) => {
  try {
    const { status, currentLocation } = req.body;
    const bus = await Bus.findById(req.params.id);

    if (!bus) {
      return res.status(404).json({ message: 'Vehicle not found' });
    }

    if (status) {
      bus.status = status;
    }

    if (currentLocation) {
      bus.currentLocation = currentLocation;
    }

    const updatedBus = await bus.save();

    const activeTrip = await Trip.findOne({
      vehicle: bus._id,
      status: { $in: ['scheduled', 'in-progress', 'delayed'] },
    }).sort({ createdAt: -1 });

    if (activeTrip) {
      if (status === 'Running') {
        activeTrip.status = 'in-progress';
      }
      if (currentLocation) {
        activeTrip.currentLocation = currentLocation;
      }
      await activeTrip.save();
    }

    return res.json(updatedBus);
  } catch (error) {
    return res.status(500).json({ message: 'Server error', error: error.message });
  }
};
