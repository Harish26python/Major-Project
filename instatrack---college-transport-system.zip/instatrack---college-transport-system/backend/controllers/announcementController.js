
import Announcement from '../models/announcementModel.js';

export const postAnnouncement = async (req, res) => {
    try {
        const { message, routeId } = req.body;
        const newAnnouncement = await Announcement.create({ message, routeId });
        res.status(201).json(newAnnouncement);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};