import Bus from '../models/busModel.js';
import Route from '../models/routeModel.js';
import User from '../models/userModel.js';
import Driver from '../models/driverModel.js';
import StudentTransport from '../models/studentTransportModel.js';
import Trip from '../models/tripModel.js';
import { buildTransportReports } from '../services/transportReportService.js';

const ensureUserRole = async (userId, role) => {
  const user = await User.findById(userId);
  if (!user || user.role !== role) {
    return null;
  }
  return user;
};

const syncVehicleAssignments = async ({ vehicleId, driverId, routeId }) => {
  const vehicle = vehicleId ? await Bus.findById(vehicleId) : null;
  const driverUser = driverId ? await User.findById(driverId) : null;
  const driverProfile = driverId ? await Driver.findOne({ user: driverId }) : null;
  const route = routeId ? await Route.findById(routeId) : null;

  if (vehicle) {
    if (driverId !== undefined) {
      vehicle.driver = driverId || null;
    }
    if (routeId !== undefined) {
      vehicle.assignedRoute = routeId || null;
    }
    await vehicle.save();
  }

  if (driverUser && driverUser.role === 'driver') {
    if (vehicleId !== undefined) {
      driverUser.busId = vehicleId || null;
    }
    if (routeId !== undefined) {
      driverUser.routeId = routeId || null;
    }
    await driverUser.save();
  }

  if (driverProfile) {
    if (vehicleId !== undefined) {
      driverProfile.assignedVehicle = vehicleId || null;
    }
    await driverProfile.save();
  }

  if (route) {
    if (vehicleId !== undefined) {
      route.assignedVehicle = vehicleId || null;
    }
    if (driverId !== undefined) {
      route.assignedDriver = driverId || null;
    }
    await route.save();
  }
};

export const listVehicles = async (_req, res) => {
  const vehicles = await Bus.find({})
    .populate('driver', 'name email instituteId')
    .populate('assignedRoute', 'routeName distance');
  return res.json(vehicles);
};

export const getVehicleById = async (req, res) => {
  const vehicle = await Bus.findById(req.params.id)
    .populate('driver', 'name email instituteId')
    .populate('assignedRoute');

  if (!vehicle) {
    return res.status(404).json({ message: 'Vehicle not found' });
  }

  return res.json(vehicle);
};

export const createVehicle = async (req, res) => {
  const vehicle = await Bus.create(req.body);
  return res.status(201).json(vehicle);
};

export const updateVehicle = async (req, res) => {
  const vehicle = await Bus.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!vehicle) {
    return res.status(404).json({ message: 'Vehicle not found' });
  }

  return res.json(vehicle);
};

export const deleteVehicle = async (req, res) => {
  const vehicle = await Bus.findById(req.params.id);
  if (!vehicle) {
    return res.status(404).json({ message: 'Vehicle not found' });
  }

  await Route.updateMany({ assignedVehicle: vehicle._id }, { $set: { assignedVehicle: null } });
  await Driver.updateMany({ assignedVehicle: vehicle._id }, { $set: { assignedVehicle: null } });
  await User.updateMany({ busId: vehicle._id }, { $set: { busId: null, routeId: null } });
  await Trip.deleteMany({ vehicle: vehicle._id });
  await vehicle.deleteOne();

  return res.json({ message: 'Vehicle deleted successfully' });
};

export const listDrivers = async (_req, res) => {
  const drivers = await Driver.find({}).populate('user', 'name email instituteId role').populate('assignedVehicle');
  return res.json(drivers);
};

export const createDriverProfile = async (req, res) => {
  const { user: userId, assignedVehicle } = req.body;

  if (userId) {
    const driverUser = await ensureUserRole(userId, 'driver');
    if (!driverUser) {
      return res.status(400).json({ message: 'Linked user must exist and have driver role.' });
    }
  }

  const driver = await Driver.create(req.body);

  if (userId) {
    await User.findByIdAndUpdate(userId, { busId: assignedVehicle || null });
  }

  return res.status(201).json(driver);
};

export const updateDriverProfile = async (req, res) => {
  const driver = await Driver.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!driver) {
    return res.status(404).json({ message: 'Driver profile not found' });
  }

  if (driver.user) {
    await User.findByIdAndUpdate(driver.user, {
      name: driver.name,
      busId: driver.assignedVehicle || null,
    });
  }

  return res.json(driver);
};

export const deleteDriverProfile = async (req, res) => {
  const driver = await Driver.findById(req.params.id);
  if (!driver) {
    return res.status(404).json({ message: 'Driver profile not found' });
  }

  if (driver.user) {
    await User.findByIdAndUpdate(driver.user, { busId: null, routeId: null });
  }

  await Route.updateMany({ assignedDriver: driver.user || null }, { $set: { assignedDriver: null } });
  await Bus.updateMany({ driver: driver.user || null }, { $set: { driver: null } });
  await driver.deleteOne();

  return res.json({ message: 'Driver profile deleted successfully' });
};

export const listRoutes = async (_req, res) => {
  const routes = await Route.find({}).populate('assignedVehicle assignedDriver');
  return res.json(routes);
};

export const getRouteById = async (req, res) => {
  const route = await Route.findById(req.params.id).populate('assignedVehicle assignedDriver');
  if (!route) {
    return res.status(404).json({ message: 'Route not found' });
  }
  return res.json(route);
};

export const createRoute = async (req, res) => {
  const payload = {
    ...req.body,
    isOptimized: Array.isArray(req.body.stops) ? req.body.stops.length > 2 : false,
  };

  const route = await Route.create(payload);

  if (route.assignedVehicle || route.assignedDriver) {
    await syncVehicleAssignments({
      vehicleId: route.assignedVehicle,
      driverId: route.assignedDriver,
      routeId: route._id,
    });
  }

  return res.status(201).json(route);
};

export const updateRoute = async (req, res) => {
  const route = await Route.findById(req.params.id);
  if (!route) {
    return res.status(404).json({ message: 'Route not found' });
  }

  Object.assign(route, req.body);
  route.isOptimized = Array.isArray(route.stops) ? route.stops.length > 2 : route.isOptimized;
  await route.save();

  if (route.assignedVehicle || route.assignedDriver) {
    await syncVehicleAssignments({
      vehicleId: route.assignedVehicle,
      driverId: route.assignedDriver,
      routeId: route._id,
    });
  }

  return res.json(route);
};

export const deleteRoute = async (req, res) => {
  const route = await Route.findById(req.params.id);
  if (!route) {
    return res.status(404).json({ message: 'Route not found' });
  }

  await Bus.updateMany({ assignedRoute: route._id }, { $set: { assignedRoute: null } });
  await User.updateMany({ routeId: route._id }, { $set: { routeId: null } });
  await StudentTransport.updateMany({ route: route._id }, { $set: { status: 'inactive' } });
  await Trip.deleteMany({ route: route._id });
  await route.deleteOne();

  return res.json({ message: 'Route deleted successfully' });
};

export const assignDriverToVehicle = async (req, res) => {
  const { driverId, vehicleId } = req.body;

  const driverUser = await ensureUserRole(driverId, 'driver');
  if (!driverUser) {
    return res.status(400).json({ message: 'Driver user not found.' });
  }

  const vehicle = await Bus.findById(vehicleId);
  if (!vehicle) {
    return res.status(404).json({ message: 'Vehicle not found.' });
  }

  const route = vehicle.assignedRoute ? await Route.findById(vehicle.assignedRoute) : null;

  await syncVehicleAssignments({
    vehicleId: vehicle._id,
    driverId: driverUser._id,
    routeId: route?._id,
  });

  return res.json({ message: 'Driver assigned to vehicle successfully.' });
};

export const assignVehicleToRoute = async (req, res) => {
  const { vehicleId, routeId } = req.body;

  const vehicle = await Bus.findById(vehicleId);
  const route = await Route.findById(routeId);

  if (!vehicle || !route) {
    return res.status(404).json({ message: 'Route or vehicle not found.' });
  }

  await syncVehicleAssignments({
    vehicleId: vehicle._id,
    driverId: route.assignedDriver || vehicle.driver || undefined,
    routeId: route._id,
  });

  return res.json({ message: 'Vehicle assigned to route successfully.' });
};

export const listStudentAssignments = async (_req, res) => {
  const assignments = await StudentTransport.find({})
    .populate('student', 'name email instituteId')
    .populate('route', 'routeName stops')
    .sort({ createdAt: -1 });
  return res.json(assignments);
};

export const createStudentAssignment = async (req, res) => {
  const { student, route, pickupPoint, dropPoint, transportFee, status } = req.body;
  const studentUser = await ensureUserRole(student, 'student');
  if (!studentUser) {
    return res.status(400).json({ message: 'Assigned user must exist and have student role.' });
  }

  const routeDoc = await Route.findById(route).populate('assignedVehicle');
  if (!routeDoc) {
    return res.status(404).json({ message: 'Route not found.' });
  }

  const activeAssignments = await StudentTransport.countDocuments({ route, status: 'active' });
  const capacity = routeDoc.assignedVehicle?.capacity ?? Number.MAX_SAFE_INTEGER;
  if (status !== 'inactive' && activeAssignments >= capacity) {
    return res.status(400).json({ message: 'Assigned vehicle capacity has been reached.' });
  }

  const assignment = await StudentTransport.findOneAndUpdate(
    { student },
    { student, route, pickupPoint, dropPoint, transportFee, status },
    { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
  );

  studentUser.routeId = route;
  studentUser.busId = routeDoc.assignedVehicle?._id || null;
  await studentUser.save();

  return res.status(201).json(assignment);
};

export const updateStudentAssignment = async (req, res) => {
  const assignment = await StudentTransport.findById(req.params.id);
  if (!assignment) {
    return res.status(404).json({ message: 'Student transport assignment not found.' });
  }

  Object.assign(assignment, req.body);
  await assignment.save();

  const routeDoc = assignment.route ? await Route.findById(assignment.route).populate('assignedVehicle') : null;
  await User.findByIdAndUpdate(assignment.student, {
    routeId: assignment.route || null,
    busId: routeDoc?.assignedVehicle?._id || null,
  });

  return res.json(assignment);
};

export const deleteStudentAssignment = async (req, res) => {
  const assignment = await StudentTransport.findById(req.params.id);
  if (!assignment) {
    return res.status(404).json({ message: 'Student transport assignment not found.' });
  }

  await User.findByIdAndUpdate(assignment.student, { routeId: null, busId: null });
  await assignment.deleteOne();

  return res.json({ message: 'Student transport assignment deleted successfully.' });
};

export const listTrips = async (req, res) => {
  const filter = {};

  if (req.user.role === 'driver') {
    filter.driver = req.user._id;
  }

  if (req.query.routeId) {
    filter.route = req.query.routeId;
  }

  const trips = await Trip.find(filter)
    .populate('vehicle route driver', 'vehicleNumber routeName name email')
    .sort({ createdAt: -1 });

  return res.json(trips);
};

export const createTrip = async (req, res) => {
  const payload = { ...req.body };
  if (req.user.role === 'driver') {
    payload.driver = req.user._id;
  }

  const trip = await Trip.create(payload);

  await Bus.findByIdAndUpdate(trip.vehicle, {
    status: trip.status === 'completed' ? 'active' : 'on_trip',
    currentLocation: trip.currentLocation,
  });

  const driverProfile = trip.driver ? await Driver.findOne({ user: trip.driver }) : null;
  if (driverProfile && trip.status === 'completed') {
    driverProfile.completedTrips += 1;
    await driverProfile.save();
  }

  return res.status(201).json(trip);
};

export const updateTrip = async (req, res) => {
  const trip = await Trip.findById(req.params.id);
  if (!trip) {
    return res.status(404).json({ message: 'Trip not found.' });
  }

  if (req.user.role === 'driver' && trip.driver?.toString() !== req.user._id.toString()) {
    return res.status(403).json({ message: 'Not authorized to update this trip.' });
  }

  Object.assign(trip, req.body);
  trip.timestamp = new Date();
  await trip.save();

  await Bus.findByIdAndUpdate(trip.vehicle, {
    status: trip.status === 'completed' ? 'active' : 'on_trip',
    currentLocation: trip.currentLocation,
  });

  const driverProfile = trip.driver ? await Driver.findOne({ user: trip.driver }) : null;
  if (driverProfile && trip.status === 'delayed') {
    driverProfile.delayedTrips += 1;
    await driverProfile.save();
  }
  if (driverProfile && trip.status === 'completed') {
    driverProfile.completedTrips += 1;
    await driverProfile.save();
  }

  return res.json(trip);
};

export const getReports = async (_req, res) => {
  const reports = await buildTransportReports();
  return res.json(reports);
};
