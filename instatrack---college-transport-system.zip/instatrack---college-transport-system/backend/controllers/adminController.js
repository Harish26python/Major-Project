import mongoose from 'mongoose';
import User from '../models/userModel.js';
import Route from '../models/routeModel.js';
import Bus from '../models/busModel.js';
import Driver from '../models/driverModel.js';
import StudentTransport from '../models/studentTransportModel.js';

const sanitizeUser = (user) => {
  const userData = user.toObject();
  delete userData.password;
  return userData;
};

export const createUser = async (req, res) => {
  try {
    if (req.user.role === 'transport_manager') {
      const forbiddenRoles = ['admin', 'transport_manager'];
      if (forbiddenRoles.includes(req.body.role)) {
        return res.status(403).json({ message: 'Transport managers may only create student or driver accounts.' });
      }
    }

    const user = new User(req.body);
    await user.save();
    return res.status(201).json(sanitizeUser(user));
  } catch (error) {
    return res.status(400).json({ message: error.message });
  }
};

export const updateUser = async (req, res) => {
  try {
    const { password, busId, routeId, ...updateData } = req.body;
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (req.user.role === 'transport_manager' && ['admin', 'transport_manager'].includes(user.role)) {
      return res.status(403).json({ message: 'Transport managers may only manage driver and student accounts.' });
    }

    if (req.user.role === 'transport_manager' && updateData.role && ['admin', 'transport_manager'].includes(updateData.role)) {
      return res.status(403).json({ message: 'Transport managers may not change role to admin or transport_manager.' });
    }

    Object.assign(user, updateData);
    if (password) {
      user.password = password;
    }

    if (busId !== undefined) {
      if (user.role !== 'driver') {
        return res.status(400).json({ message: 'Only drivers may be assigned a bus.' });
      }
      user.busId = busId || null;
    }

    if (routeId !== undefined) {
      if (user.role !== 'student') {
        return res.status(400).json({ message: 'Only students may be assigned a route directly.' });
      }
      user.routeId = routeId || null;
    }

    await user.save();

    if (user.role === 'driver') {
      const driverProfile = await Driver.findOne({ user: user._id });
      if (driverProfile) {
        driverProfile.name = user.name;
        if (busId !== undefined) {
          driverProfile.assignedVehicle = busId || null;
        }
        await driverProfile.save();
      }
    }

    if (user.role === 'student' && routeId !== undefined) {
      const studentTransport = await StudentTransport.findOne({ student: user._id });
      if (studentTransport) {
        studentTransport.route = routeId || null;
        await studentTransport.save();
      }
    }

    return res.json(sanitizeUser(user));
  } catch (error) {
    return res.status(400).json({ message: error.message });
  }
};

export const deleteUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (req.user.role === 'transport_manager' && ['admin', 'transport_manager'].includes(user.role)) {
      return res.status(403).json({ message: 'Transport managers may only delete driver and student accounts.' });
    }

    await User.findByIdAndDelete(req.params.id);
    await Driver.findOneAndDelete({ user: req.params.id });
    await StudentTransport.findOneAndDelete({ student: req.params.id });

    return res.json({ message: 'User deleted successfully' });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

export const createRoute = async (req, res) => {
  try {
    const route = new Route(req.body);
    await route.save();
    return res.status(201).json(route);
  } catch (error) {
    return res.status(400).json({ message: error.message });
  }
};

export const updateRoute = async (req, res) => {
  try {
    const route = await Route.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    return res.json(route);
  } catch (error) {
    return res.status(400).json({ message: error.message });
  }
};

export const deleteRoute = async (req, res) => {
  try {
    await Route.findByIdAndDelete(req.params.id);
    return res.json({ message: 'Route deleted successfully' });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

/** Normalize plate numbers: trim, Unicode compatibility fold, uppercase (matches Indian RC display). */
const normalizeVehicleNumber = (raw) => {
  if (raw === undefined || raw === null) return undefined;
  const s = String(raw).trim().normalize('NFKC');
  return s ? s.toUpperCase() : undefined;
};

/** Pull conflicting registration from Mongo duplicate-key errors (shape varies by driver / Mongoose version). */
const extractDuplicateVehicleNumber = (error) => {
  if (!error || error.code !== 11000) return null;

  const readKv = (e) => {
    if (!e) return null;
    const kv = e.keyValue ?? e.errorResponse?.keyValue;
    if (kv && typeof kv === 'object') {
      const v = kv.vehicleNumber ?? kv.number;
      if (v != null) return String(v);
    }
    return null;
  };

  const fromKv = readKv(error) || readKv(error.cause);
  if (fromKv) return fromKv;

  const msg = [error.message, error.errmsg, error.errorResponse?.errmsg, error.cause?.message]
    .filter(Boolean)
    .join(' | ');
  const dupKeyQuoted = msg.match(/dup key:\s*\{[^}]*vehicleNumber:\s*"([^"\\]+)"/i)
    || msg.match(/dup key:\s*\{[^}]*vehicleNumber:\s*'([^'\\]+)'/i);
  return dupKeyQuoted ? dupKeyQuoted[1] : null;
};

const findConflictingBusByPlate = (canonicalPlate) =>
  Bus.findOne({ vehicleNumber: canonicalPlate })
    .collation({ locale: 'en', strength: 2 })
    .select('_id vehicleNumber')
    .lean();

const duplicateVehicleMessage = (error, attemptedPlate) => {
  const found = extractDuplicateVehicleNumber(error);
  const dbName = mongoose.connection?.name || '';
  const dbHint = dbName ? `Connected MongoDB database name: "${dbName}". ` : '';
  if (found) {
    return `${dbHint}Registration "${found}" already exists in the "buses" collection. Refresh the admin page, or in Atlas/Compass open that database → collection "buses" and search for "${found}".`;
  }
  if (attemptedPlate) {
    return `${dbHint}Registration "${attemptedPlate}" hit a duplicate-key error but no matching bus was returned by a normal query—often a stale unique index. Restart the server (indexes sync on startup), or in Compass open this database → "buses" → Indexes → drop the index on vehicleNumber, then restart.`;
  }
  return `${dbHint}That vehicle number conflicts with the unique index on vehicleNumber.`;
};

const formatBusPayload = (payload) => {
  const { vehicleNumber, type, capacity, insuranceExpiry, status, driver, assignedRoute, currentLocation, fuelConsumption, maintenanceLogs } = payload;
  const formatted = {
    vehicleNumber: normalizeVehicleNumber(vehicleNumber),
    type,
    capacity: capacity !== undefined ? Number(capacity) : undefined,
    insuranceExpiry: insuranceExpiry ? new Date(insuranceExpiry) : undefined,
    status,
    driver: driver || null,
    assignedRoute: assignedRoute || null,
    currentLocation: currentLocation || undefined,
    fuelConsumption: fuelConsumption !== undefined ? Number(fuelConsumption) : undefined,
    maintenanceLogs,
  };
  return Object.fromEntries(Object.entries(formatted).filter(([, value]) => value !== undefined));
};

const getValidationMessage = (error, attemptedVehicleNumber) => {
  if (error.code === 11000) {
    return duplicateVehicleMessage(error, attemptedVehicleNumber);
  }

  if (error.name === 'ValidationError') {
    return Object.values(error.errors).map((err) => err.message).join(', ');
  }

  return error.message;
};

export const createBus = async (req, res) => {
  let attemptedPlate;
  try {
    const payload = formatBusPayload(req.body);
    attemptedPlate = payload.vehicleNumber;

    if (!payload.vehicleNumber) {
      return res.status(400).json({ message: 'Vehicle number is required.' });
    }

    if (payload.capacity !== undefined && Number.isNaN(payload.capacity)) {
      return res.status(400).json({ message: 'Capacity must be a valid number.' });
    }

    const clash = await findConflictingBusByPlate(payload.vehicleNumber);
    if (clash) {
      return res.status(400).json({
        message: `A bus already exists with registration "${clash.vehicleNumber}" (id: ${clash._id}). Delete or edit it below, or remove that document in MongoDB, then try again.`,
      });
    }

    const bus = new Bus(payload);
    try {
      await bus.save();
      return res.status(201).json(bus);
    } catch (saveErr) {
      if (saveErr.code === 11000) {
        await Bus.syncIndexes().catch(() => {});
        const retry = new Bus(payload);
        await retry.save();
        return res.status(201).json(retry);
      }
      throw saveErr;
    }
  } catch (error) {
    return res.status(400).json({ message: getValidationMessage(error, attemptedPlate) });
  }
};

export const updateBus = async (req, res) => {
  let attemptedPlate;
  try {
    const payload = formatBusPayload(req.body);
    attemptedPlate = payload.vehicleNumber;

    const bus = await Bus.findByIdAndUpdate(req.params.id, payload, { new: true, runValidators: true });
    return res.json(bus);
  } catch (error) {
    return res.status(400).json({ message: getValidationMessage(error, attemptedPlate) });
  }
};

export const deleteBus = async (req, res) => {
  try {
    await Bus.findByIdAndDelete(req.params.id);
    return res.json({ message: 'Bus deleted successfully' });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};
