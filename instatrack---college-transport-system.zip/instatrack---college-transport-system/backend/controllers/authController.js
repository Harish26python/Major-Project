import User from '../models/userModel.js';
import generateToken from '../utils/generateToken.js';

const sanitizeUser = (user) => ({
  _id: user._id,
  name: user.name,
  email: user.email,
  role: user.role,
  instituteId: user.instituteId,
  routeId: user.routeId,
  busId: user.busId,
  createdAt: user.createdAt,
  updatedAt: user.updatedAt,
});

export const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user || !(await user.matchPassword(password))) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    return res.json({
      token: generateToken(user._id),
      user: sanitizeUser(user),
    });
  } catch (error) {
    return res.status(500).json({ message: 'Server error', error: error.message });
  }
};

export const signup = async (req, res) => {
  const { name, email, password, role, instituteId } = req.body;

  if (!name || !email || !password || !role || !instituteId) {
    return res.status(400).json({ message: 'Please provide name, email, password, role, and institute ID.' });
  }

  if (!['student', 'driver'].includes(role)) {
    return res.status(400).json({ message: 'Signup is only available for student and driver roles.' });
  }

  try {
    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: 'User with this email already exists.' });
    }

    const user = await User.create({ name, email, password, role, instituteId });

    return res.status(201).json({
      token: generateToken(user._id),
      user: sanitizeUser(user),
    });
  } catch (error) {
    if (error.code === 11000) {
      const duplicateField = Object.keys(error.keyPattern || {})[0] || 'field';
      const message = duplicateField === 'email'
        ? 'User with this email already exists.'
        : `Duplicate value for ${duplicateField}.`;
      return res.status(400).json({ message });
    }

    return res.status(500).json({ message: 'Server error', error: error.message });
  }
};

export const getCurrentUser = async (req, res) => res.json({ user: sanitizeUser(req.user) });
