import Route from '../models/routeModel.js';
import Bus from '../models/busModel.js';
import Driver from '../models/driverModel.js';
import StudentTransport from '../models/studentTransportModel.js';
import Trip from '../models/tripModel.js';

export const buildTransportReports = async () => {
  const [routes, vehicles, drivers, assignments, trips] = await Promise.all([
    Route.find({}).populate('assignedVehicle assignedDriver'),
    Bus.find({}).populate('driver assignedRoute'),
    Driver.find({}).populate('user assignedVehicle'),
    StudentTransport.find({ status: 'active' }).populate('student route'),
    Trip.find({}).populate('vehicle route driver').sort({ createdAt: -1 }),
  ]);

  const routeWiseStudentList = routes.map((route) => ({
    routeId: route._id,
    routeName: route.routeName,
    distance: route.distance,
    assignedVehicle: route.assignedVehicle?.vehicleNumber || null,
    assignedDriver: route.assignedDriver?.name || null,
    students: assignments
      .filter((assignment) => assignment.route?._id?.toString() === route._id.toString())
      .map((assignment) => ({
        studentId: assignment.student?._id,
        studentName: assignment.student?.name,
        pickupPoint: assignment.pickupPoint,
        dropPoint: assignment.dropPoint,
      })),
  }));

  const vehicleUsage = vehicles.map((vehicle) => {
    const vehicleTrips = trips.filter((trip) => trip.vehicle?._id?.toString() === vehicle._id.toString());
    return {
      vehicleId: vehicle._id,
      vehicleNumber: vehicle.vehicleNumber,
      type: vehicle.type,
      status: vehicle.status,
      assignedRoute: vehicle.assignedRoute?.routeName || null,
      tripCount: vehicleTrips.length,
      latestLocation: vehicle.currentLocation,
      insuranceExpiry: vehicle.insuranceExpiry,
      maintenanceLogs: vehicle.maintenanceLogs.length,
      fuelConsumption: vehicle.fuelConsumption,
    };
  });

  const driverPerformance = drivers.map((driver) => {
    const relatedTrips = trips.filter((trip) => trip.driver?._id?.toString() === driver.user?._id?.toString());
    const delayedTrips = relatedTrips.filter((trip) => trip.status === 'delayed').length;
    const completedTrips = relatedTrips.filter((trip) => trip.status === 'completed').length;

    return {
      driverId: driver._id,
      name: driver.name,
      assignedVehicle: driver.assignedVehicle?.vehicleNumber || null,
      completedTrips,
      delayedTrips,
      status: driver.status,
      licenseExpiry: driver.licenseExpiry,
    };
  });

  const transportFeeReports = assignments.map((assignment) => ({
    assignmentId: assignment._id,
    studentName: assignment.student?.name,
    routeName: assignment.route?.routeName,
    transportFee: assignment.transportFee,
    status: assignment.status,
  }));

  return {
    routeWiseStudentList,
    vehicleUsage,
    driverPerformance,
    transportFeeReports,
    tripSummary: {
      totalTrips: trips.length,
      delayedTrips: trips.filter((trip) => trip.status === 'delayed').length,
      completedTrips: trips.filter((trip) => trip.status === 'completed').length,
    },
  };
};
