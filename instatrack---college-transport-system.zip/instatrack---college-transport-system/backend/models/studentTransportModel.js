import mongoose from 'mongoose';

const StudentTransportSchema = new mongoose.Schema({
  student: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true,
  },
  route: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Route',
    required: true,
  },
  pickupPoint: { type: String, required: true, trim: true },
  dropPoint: { type: String, required: true, trim: true },
  transportFee: { type: Number, default: 0, min: 0 },
  status: {
    type: String,
    enum: ['active', 'inactive'],
    default: 'active',
  },
}, { timestamps: true });

const StudentTransport = mongoose.model('StudentTransport', StudentTransportSchema);
export default StudentTransport;
