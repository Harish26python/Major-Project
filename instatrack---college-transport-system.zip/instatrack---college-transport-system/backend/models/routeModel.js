import mongoose from 'mongoose';

const StopSchema = new mongoose.Schema({
  stopName: {
    type: String,
    required: true,
    trim: true,
    alias: 'name',
  },
  arrivalTime: {
    type: String,
    required: true,
    trim: true,
    alias: 'time',
  },
}, { _id: false });

const RouteSchema = new mongoose.Schema({
  routeName: {
    type: String,
    required: true,
    trim: true,
    alias: 'name',
  },
  stops: {
    type: [StopSchema],
    default: [],
  },
  distance: { type: Number, default: 0, min: 0 },
  assignedVehicle: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Bus',
    default: null,
    alias: 'busId',
  },
  assignedDriver: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null,
  },
  estimatedDurationMinutes: { type: Number, default: 0, min: 0 },
  isOptimized: { type: Boolean, default: false },
}, { timestamps: true, toJSON: { virtuals: true }, toObject: { virtuals: true } });

const Route = mongoose.model('Route', RouteSchema);
export default Route;
