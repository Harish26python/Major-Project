import mongoose from 'mongoose';

const LocationSchema = new mongoose.Schema({
  lat: { type: Number, default: 0 },
  lng: { type: Number, default: 0 },
}, { _id: false });

const MaintenanceLogSchema = new mongoose.Schema({
  note: { type: String, required: true, trim: true },
  servicedAt: { type: Date, default: Date.now },
  cost: { type: Number, default: 0, min: 0 },
}, { _id: false });

const BusSchema = new mongoose.Schema({
  vehicleNumber: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },
  type: {
    type: String,
    enum: ['bus', 'van'],
    default: 'bus',
  },
  capacity: { type: Number, required: true, min: 1 },
  driver: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null,
    alias: 'driverId',
  },
  assignedRoute: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Route',
    default: null,
    alias: 'routeId',
  },
  insuranceExpiry: { type: Date, default: null },
  status: {
    type: String,
    enum: ['active', 'inactive', 'maintenance', 'on_trip', 'Idle', 'Running', 'Maintenance'],
    default: 'active',
  },
  maintenanceLogs: {
    type: [MaintenanceLogSchema],
    default: [],
  },
  currentLocation: {
    type: LocationSchema,
    default: () => ({ lat: 0, lng: 0 }),
    alias: 'location',
  },
  fuelConsumption: { type: Number, default: 0, min: 0 },
}, { timestamps: true, toJSON: { virtuals: true }, toObject: { virtuals: true } });

const Bus = mongoose.model('Bus', BusSchema);
export default Bus;
