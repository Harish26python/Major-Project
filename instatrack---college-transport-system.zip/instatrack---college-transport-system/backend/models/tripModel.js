import mongoose from 'mongoose';

const TripLocationSchema = new mongoose.Schema({
  lat: { type: Number, required: true },
  lng: { type: Number, required: true },
}, { _id: false });

const TripSchema = new mongoose.Schema({
  vehicle: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Bus',
    required: true,
  },
  route: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Route',
    required: true,
  },
  driver: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null,
  },
  currentLocation: {
    type: TripLocationSchema,
    required: true,
  },
  status: {
    type: String,
    enum: ['scheduled', 'in-progress', 'on-time', 'delayed', 'completed'],
    default: 'scheduled',
  },
  timestamp: { type: Date, default: Date.now },
}, { timestamps: true });

const Trip = mongoose.model('Trip', TripSchema);
export default Trip;
