import mongoose from 'mongoose';

const DriverSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null,
    unique: true,
    sparse: true,
  },
  name: { type: String, required: true, trim: true },
  phone: { type: String, required: true, trim: true },
  licenseNumber: { type: String, required: true, unique: true, trim: true },
  licenseExpiry: { type: Date, required: true },
  assignedVehicle: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Bus',
    default: null,
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'on_leave'],
    default: 'active',
  },
  completedTrips: { type: Number, default: 0, min: 0 },
  delayedTrips: { type: Number, default: 0, min: 0 },
}, { timestamps: true });

const Driver = mongoose.model('Driver', DriverSchema);
export default Driver;
