import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const UserSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, minlength: 6 },
  instituteId: { type: String, required: true, trim: true },
  role: {
    type: String,
    enum: ['student', 'driver', 'admin', 'transport_manager'],
    required: true,
  },
  routeId: { type: mongoose.Schema.Types.ObjectId, ref: 'Route', default: null },
  busId: { type: mongoose.Schema.Types.ObjectId, ref: 'Bus', default: null },
}, { timestamps: true });

UserSchema.pre('save', async function preSave(next) {
  if (!this.isModified('password')) {
    return next();
  }

  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  return next();
});

UserSchema.methods.matchPassword = async function matchPassword(enteredPassword) {
  return bcrypt.compare(enteredPassword, this.password);
};

const User = mongoose.model('User', UserSchema);
export default User;
