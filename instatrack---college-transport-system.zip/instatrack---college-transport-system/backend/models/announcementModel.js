
import mongoose from 'mongoose';

const AnnouncementSchema = new mongoose.Schema({
  message: { type: String, required: true },
  routeId: { type: mongoose.Schema.Types.ObjectId, ref: 'Route', default: null },
}, { timestamps: true });

const Announcement = mongoose.model('Announcement', AnnouncementSchema);
export default Announcement;