import dotenv from 'dotenv';
import User from '../models/userModel.js';
import Bus from '../models/busModel.js';
import Route from '../models/routeModel.js';
import Driver from '../models/driverModel.js';
import StudentTransport from '../models/studentTransportModel.js';
import Trip from '../models/tripModel.js';
import connectDB from '../config/db.js';

dotenv.config();

const importData = async () => {
  await connectDB();

  try {
    await Promise.all([
      Trip.deleteMany(),
      StudentTransport.deleteMany(),
      Driver.deleteMany(),
      Route.deleteMany(),
      Bus.deleteMany(),
      User.deleteMany(),
    ]);

    console.log('Old data cleared...');

    const [admin, transportManager, driverUser, student] = await User.create([
      {
        name: 'Admin User',
        email: 'admin@college.edu',
        password: 'password123',
        instituteId: 'ADM001',
        role: 'admin',
      },
      {
        name: 'Transport Manager',
        email: 'manager@college.edu',
        password: 'password123',
        instituteId: 'TRM001',
        role: 'transport_manager',
      },
      {
        name: 'John Driver',
        email: 'john@college.edu',
        password: 'password123',
        instituteId: 'DRV001',
        role: 'driver',
      },
      {
        name: 'Alex Student',
        email: 'alex@college.edu',
        password: 'password123',
        instituteId: 'STU101',
        role: 'student',
      },
    ]);

    const vehicle = await Bus.create({
      vehicleNumber: 'C-101',
      type: 'bus',
      capacity: 50,
      driver: driverUser._id,
      insuranceExpiry: new Date('2026-12-31'),
      status: 'active',
      maintenanceLogs: [
        { note: 'Quarterly service completed', servicedAt: new Date('2026-03-28'), cost: 2500 },
      ],
      currentLocation: { lat: 22.5726, lng: 88.3639 },
      fuelConsumption: 12.5,
    });

    const route = await Route.create({
      routeName: 'Downtown Express',
      stops: [
        { stopName: 'Central Library', arrivalTime: '08:00 AM' },
        { stopName: 'Main Street', arrivalTime: '08:15 AM' },
        { stopName: 'City Hall', arrivalTime: '08:30 AM' },
        { stopName: 'College Campus', arrivalTime: '09:00 AM' },
      ],
      distance: 18.5,
      assignedVehicle: vehicle._id,
      assignedDriver: driverUser._id,
      estimatedDurationMinutes: 60,
      isOptimized: true,
    });

    const driverProfile = await Driver.create({
      user: driverUser._id,
      name: driverUser.name,
      phone: '9876543210',
      licenseNumber: 'DL-4589784',
      licenseExpiry: new Date('2027-08-15'),
      assignedVehicle: vehicle._id,
      status: 'active',
    });

    const studentTransport = await StudentTransport.create({
      student: student._id,
      route: route._id,
      pickupPoint: 'Main Street',
      dropPoint: 'College Campus',
      transportFee: 1800,
      status: 'active',
    });

    const trip = await Trip.create({
      vehicle: vehicle._id,
      route: route._id,
      driver: driverUser._id,
      currentLocation: { lat: 22.5801, lng: 88.3712 },
      status: 'on-time',
    });

    driverUser.busId = vehicle._id;
    driverUser.routeId = route._id;
    student.routeId = route._id;
    student.busId = vehicle._id;
    await Promise.all([driverUser.save(), student.save()]);

    vehicle.assignedRoute = route._id;
    await vehicle.save();

    console.log('Data Imported Successfully!');
    console.log({
      admin: admin.email,
      transportManager: transportManager.email,
      driver: driverUser.email,
      student: student.email,
      vehicle: vehicle.vehicleNumber,
      route: route.routeName,
      driverProfileId: driverProfile._id,
      studentTransportId: studentTransport._id,
      tripId: trip._id,
    });
    process.exit(0);
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

const destroyData = async () => {
  try {
    await connectDB();
    await Promise.all([
      Trip.deleteMany(),
      StudentTransport.deleteMany(),
      Driver.deleteMany(),
      Route.deleteMany(),
      Bus.deleteMany(),
      User.deleteMany(),
    ]);
    console.log('Data Destroyed!');
    process.exit(0);
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

if (process.argv[2] === '-d') {
  destroyData();
} else {
  importData();
}
